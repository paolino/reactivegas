# Independent S2R candidate audit — final report

**Terminal verdict: AUDIT-FINDINGS.** No blocking functional defect was demonstrated in the commissioned current-configuration behavior. One **ADVISORY documentation finding remains OPEN** within Element 1: the shipped missing-REACTIVEGAS_ROOT fail-closed claim is contradicted by P22. The mandatory shell supplies that variable; no present mandatory-path bypass was demonstrated. The report is complete, not an acceptance or merge decision.

Candidate: `714cb2a8536b24bf735295137e8f907782228380`; accepted parent: `d67032313acf3699cc50358a057391b88d002192`; lower accepted S1: `4a6cd87fcbc3e4a536bbc9f240f5efe5704022af`. Subject: issue #66 S2R, draft PR88, audited in detached `/code/reactivegas-66-s2r-audit`. No remote status was refreshed for this closeout.

## Authority, identity and reporting release

This is the same independent Codex seat, model gpt-6-astra, model_reasoning_effort=high, PID/PGID 1664317, pane %548; implementation owner Muse uses a distinct worktree and context. The retained process-identity and pause receipts establish identity; no fresh START is claimed. The valid original START was 2026-09-05T14:01:11.657Z. The first start-live PID was a Bash wrapper and is explicitly superseded by process-identity.json, not erased.

Full original S2R A/B/C mandate and AMENDMENT-1 are bound in evidence/original-mandate-v2.txt, SHA-256 `7cfb7aec95a37448ac7be3c65d900aa47b34fc70127c6d827fa12337e1cf421b`. Frozen executable base contract concatenation is `39d6aa4e2c0c0170ff28832f4794293dca64aa3ab65ec6b89ab0924199ce3433`. Admitted owner packet is admitted/SUBMISSION-ADMITTED.md, `32299d25cae31c9dcd8a6d6737e61bb6fe35b48bd4a8e6f041949cff13319bff`. Admission and base-contract receipts are retained. The obsolete S2-MANDATE proposal is history, not authority. No owner or earlier auditor PASS closes a row here.

NOTE-002 restores mandatory rebuilt-base comparison and supersedes stale brief details. A-002 reinstates the original A-001 layer ruling; A-003 is the operative Q-002 resolution: S9/S10 withdrawn and never executed, eight required substantive purposes plus one expressly authorized replacement setup attempt, total ceiling nine. A-001's categorical claim that input-injected whole-path tests only test a harness is withdrawn; the actual reason for direct omission/missing-authority controls is the contract's required layer. The original dispatch and old grants remain history, not new allowances.

The operator pause preserved the complete state before report creation. NOTE-006, release token RELEASE-STORIES-20260905, explicitly releases this seat for this report, row ledger and hash handoff only. STATUS.md acknowledges RESUMED. No builds, elaborations, completed controls, candidate checks or campaign rows were rerun/opened during closeout. Accounting is unchanged: **9/9 substantive, 29/30 targeted**, 38 receipts. One targeted reserve remains unused. Local-only, no author contact, no pane/composer messages, no candidate edit, push, PR action, publication or merge. All failed attempts and caches are preserved; no pane or cache retirement is authorized by this reporting-only release.

## Scope and outcome

The finite denominator is the original A1–A8 (A2 replaced by A2′), B1–B6, C and §5; AMENDMENT-1; named F-001–F-004/G-001; five successor elements; and accepted-exporter integration/provenance. This is a full audit of those gates and naming changes, not a new all-theorems semantic, simulator, proof-completeness or exporter mutation audit.

The candidate's six-file delta adds mandatory axiom checking; derives source, compiled-module and theorem inventories; replaces a numeric census quota with source/compiled reconciliation; canonicalizes resolved-artifact containment; preserves nine computations under accurate names; removes three unused exports; and corrects one doc-comment path. The broader aggregate diff contains already accepted exporter integration. The retained six-file diff, not that aggregate, determines this submission's edits.

The independent cold just lean and exact full just ci pass. Baseline S=27 tracked/walked, B=27, T=1214 occurrences/1213 distinct/1213 fold; source/backed declarations=163/163. The separate 14-constructor inversion denominator remains 14/14, with withheld-backdonate 13/14. These are observed counts, not required quotas. P17 records identical compiled identities and 262 Std dependencies excluded. Logs print all identities, not just these totals.

Omission closure is independent: P02/P03 each reject only their intended project-module omission, and P04/P05 pass when only the matching guard is disabled. The owner’s differently numbered P26/P27 stale-olean-contaminated logs remain invalid as unmasked necessity evidence. They are not retroactively repaired. S3R rejects sorryAx at unchanged census, while S6 preserves the poison and passes without the gate; S4 rejects direct and def-mediated forbidden-axiom uses. These observations establish actual enforcement, not merely a green recipe.

## Finding and bounded observations

**Element 1 — ADVISORY, OPEN: missing-root documentation exceeds behavior.** The new gate header says missing/unresolvable REACTIVEGAS_ROOT fails closed. The driver uses getD ".". P22 runs the driver with REACTIVEGAS_ROOT unset from the Lean cwd and gets exit 0 and axiom-gate: ok with the baseline identities. This contradicts the missing-variable portion of the documentation. The mandatory wrapper exports the root and S1/S2 pass, so this is not evidence of a present mandatory-path bypass. Owner of disposition: commissioning owner, to route to the implementation owner if a correction is commissioned. No remedy is authored by the auditor. G-001/Element 5 concern LEAN_PATH and are separately CLOSED by P07/P08. Root canonicalization failures were not independently exercised and are not inferred from those controls.

**NOTE-004 — not a present implementation finding, with reason.** The resolver establishes loaded-artifact containment under a canonical root together with S/B identity reconciliation. It does not establish each artifact's package-specific source origin. Recorded inspection found no require, packages=[], and no populated .lake/packages; observed dependency artifacts resolve outside the root. There is therefore no present materialized in-root dependency exhibiting misclassification. The physical-layout assumption must stay explicit. A future dependency physically under .lake/packages would satisfy containment and could yield false project classification/extra-module refusal. Aliased paths into the Nix store do not test that layout. Trailing slash construction closes the distinct lexical sibling-prefix issue by inspection. Neither universal ownership nor shadow-name safety is claimed.

**NOTE-005 — comparator limit closed by execution, not qualification alone.** P25's preliminary primitive inequality was not a negative of the comparison loop. P27 supplies a changed value through that actual loop and gets the named value mismatch. P28 feeds an in-memory wrapper reference to the actual consumer scan and gets consumers=1 followed by its actual assertion failure. P29 repeats all nine expression comparisons and the complete 27-module/3385-constant scan with opaque bodies included: two positive edges, zero removed-wrapper consumers, zero opaque bodies present. No candidate source/build was altered for these three targeted controls. The separate type-mismatch branch was not individually challenged and remains listed as untested.

**Scope limits are not silently CLOSED.** CI-T-SHARED-FILTER and shadow-name independence remain the predeclared bounded advisories outside expansion. The guard ledger names unexecuted exception/zero/type branches OPEN and names construction-only arguments as such. No claim of exhaustive mutation coverage, independent theorem sources, mathematical totality, universal package ownership or semantic adequacy of all 1213 statements is made. Those guard entries are not new mandatory campaign rows. No required named control is missing; the Element 1 documentation subclaim remains openly contradicted rather than reasoned closed.

## Rebuilt-base provenance and naming preservation

NOTE-002 licenses d670323 rather than 4a6 because the three owned Lean blobs are identical at both bases: Invariants d6d05c2e7436c0c4507f747bdddda1f98f7bbe3a; TraceTests 509d032def0e45996eb57d41b19fafe190c13d6e; Predicates 2b2cf73f238a7b24c1c10436abb76e22ac3a6255. The later base also includes the actual 27-module exporter extent. S8 verifies all 28 relevant .lean/config source hashes against base Git, removes affected compiled outputs in the separate base cache and visibly rebuilds Predicates, Invariants and TraceTests. Unaffected dependencies are justified reuse, not represented as freshly recompiled. P29 imports the base artifacts from that cache and candidate artifacts from the clean candidate cache.

Nine type/value expression equalities are established under only licensed constant-name replacement. The removed wrappers are independently present in base and absent in candidate; compiled consumer scan includes types and values, including opaque bodies (none present), over the stated 3385 constants. This establishes value preservation and lack of base consumers in that extent, not external API compatibility with unknown clients. Full nine-pair identities and observed outputs are in P29 and the row ledger.

## Integrated row decisions

Each row below has one verdict, the command(s) actually executed, the observation, and its limits. Commands are transcribed from the original invocation events; individual receipts carry command and output hashes. Inspection-only closure says so. Full machine-readable copies are ROW-LEDGER.json and EXECUTION-LEDGER.json.

## A1 — Independent S/B/T derivation and reconciliation

**CLOSED.** Severity: BLOCKING requirement. Method: Execution plus implementation inspection.

- [S1-cold-lean](../evidence/S1-cold-lean.log) (exit 0): `nix develop --quiet -c just lean`; [receipt](../evidence/S1-cold-lean.receipt).
- [P02-s-minus-b](../evidence/P02-s-minus-b.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe s-minus-b`; [receipt](../evidence/P02-s-minus-b.receipt).
- [P03-b-minus-s](../evidence/P03-b-minus-s.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe b-minus-s`; [receipt](../evidence/P03-b-minus-s.receipt).
- [P04-s-minus-b-disabled](../evidence/P04-s-minus-b-disabled.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe s-minus-b-disabled`; [receipt](../evidence/P04-s-minus-b-disabled.receipt).
- [P05-b-minus-s-disabled](../evidence/P05-b-minus-s-disabled.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe b-minus-s-disabled`; [receipt](../evidence/P05-b-minus-s-disabled.receipt).
- [P17-independent-extent](../evidence/P17-independent-extent.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe extent`; [receipt](../evidence/P17-independent-extent.receipt).
- [P26-source-discovery-controls](../evidence/P26-source-discovery-controls.log) (exit 0): `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/source-discovery-tests.cjs`; [receipt](../evidence/P26-source-discovery-controls.receipt).

Observation: Baseline source tracked/walked 27/27; compiled project modules 27, including Reactivegas.CorpusExport; theorem walk 1214 occurrences, 1213 distinct, fold 1213. S is git/walk discovery; B comes from environment headers filtered by canonical resolved-artifact containment; T comes from compiled thmInfo. P17 independently reads back the same 27 modules and 1213 identities, excluding 262 Std modules. P02 rejects only missing Reactivegas.TraceTests; P03 rejects only extra KelGroups.Tests. The identical defects pass in P04/P05 with only the respective omission guard disabled. P26 exercises the production axiom-script discovery prefix on real git/walk fixtures: positive 2/2; untracked C, missing B, zero walked and zero tracked each reject.

Boundary: The two T traversals share thmInfo and B filtering; they are not two independent theorem sources. Ownership means current loader/artifact containment, not universal package provenance. See Elements 1–2 and the guard ledger.

## A2-prime — Quota removal and all eight amended constraints

**CLOSED.** Severity: BLOCKING requirement. Method: Execution; inspection explicitly identified for constraints 7–8 and zero guards.

- [S1-cold-lean](../evidence/S1-cold-lean.log) (exit 0): `nix develop --quiet -c just lean`; [receipt](../evidence/S1-cold-lean.receipt).
- [S5-extension-vendor](../evidence/S5-extension-vendor.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`; [receipt](../evidence/S5-extension-vendor.receipt).
- [P24-source-census-truncation](../evidence/P24-source-census-truncation.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe census-truncation`; [receipt](../evidence/P24-source-census-truncation.receipt).
- [S3R-sorry](../evidence/S3R-sorry.log) (exit 1): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 sorry`; [receipt](../evidence/S3R-sorry.receipt).
- [S4-axiom](../evidence/S4-axiom.log) (exit 1): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 axiom`; [receipt](../evidence/S4-axiom.receipt).
- [P29-compiled-base-comparison-complete](../evidence/P29-compiled-base-comparison-complete.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-base-v2`; [receipt](../evidence/P29-compiled-base-comparison-complete.receipt).

Observation: 1: source/elaborated reconciliation remains, baseline 163/163. 2: source parsing and compiled declaration ranges are separate inputs, not two counters from one list. 3: registered AuditOutside.StdClean with validExtension passes the mandatory path, raising modules to 28, theorem identities to 1214 and source/backed declarations to 164. 4: P24 removes the compiled counterpart of i57_noexpiry_holds and rejects its exact source location, with declared=163/backed=162. 5: S3R rejects sorryAx at unchanged 163/163; S4 rejects auditForbidden in both using theorems at 165/165. 6: actual modules/theorem identities/counts appear in logs; expectedDeclarations and its quota assertions are deleted, no replacement numeric quota in executable logic. 7: the six requiredInversions and their checks are unchanged in the retained submission diff and run in S1/S2; overall constructor coverage remains 14/14 and the withheld-backdonate control 13/14. 8: the six-file submission diff changes no model definition; P29 establishes compiled type/value equality for all nine licensed renames.

Boundary: Nonzero source/backed census guards are present by inspection; their individual failure branches were not mutated. P24 tests the combined missing-identity/count failure, not sole necessity of each redundant diagnostic. The 163 source declarations and 1213 generated-inclusive theorem identities are different denominators.

## A3 — Cold provenance

**CLOSED.** Severity: BLOCKING requirement. Method: Preserved START and cold execution.

- [S1-cold-lean](../evidence/S1-cold-lean.log) (exit 0): `nix develop --quiet -c just lean`; [receipt](../evidence/S1-cold-lean.receipt).

Observation: Valid START at 2026-09-05T14:01:11.657Z recorded clean detached candidate and zero .olean files. S1 then completed the actual mandatory Lean recipe in 70563ms. Evidence/start-live.json is retained with its original wrapper-PID error; evidence/process-identity.json and the journal correct the agent identity to PID/PGID 1664317. No inherited auditor verdict is used.

Boundary: Cold means the project compiled outputs were absent; Nix/toolchain dependencies can be cached. No second cold run was needed or performed during closeout.

## A4 — Nonzero S, B and T

**CLOSED.** Severity: BLOCKING requirement. Method: Isolated driver controls and shell fixture controls.

- [P06-tzero](../evidence/P06-tzero.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe tzero`; [receipt](../evidence/P06-tzero.receipt).
- [P09-szero](../evidence/P09-szero.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe szero-isolated`; [receipt](../evidence/P09-szero.receipt).
- [P10-bzero](../evidence/P10-bzero.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe bzero-isolated`; [receipt](../evidence/P10-bzero.receipt).
- [P26-source-discovery-controls](../evidence/P26-source-discovery-controls.log) (exit 0): `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/source-discovery-tests.cjs`; [receipt](../evidence/P26-source-discovery-controls.receipt).

Observation: P06 has S/B=27/27 and both well-typed T producers empty: sole derived-zero-theorems finding. P09 has empty S with the B-minus-S companion disabled: sole zero-source finding. P10 imports Lean only and has actual empty B; S/T-zero companions are disabled to isolate sole zero-built finding. P26 separately reaches shell zero-tracked and zero-walked failures.

Boundary: P09/P10 explicitly alter companion guards for attribution. They are isolated instruments, not a claim that the unmodified gate produces only one diagnostic on every empty input.

## A5 — Added, truncated, removed module and sorry controls

**CLOSED.** Severity: BLOCKING requirement. Method: Mandatory-path and direct-driver execution.

- [S5-extension-vendor](../evidence/S5-extension-vendor.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`; [receipt](../evidence/S5-extension-vendor.receipt).
- [P02-s-minus-b](../evidence/P02-s-minus-b.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe s-minus-b`; [receipt](../evidence/P02-s-minus-b.receipt).
- [P03-b-minus-s](../evidence/P03-b-minus-s.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe b-minus-s`; [receipt](../evidence/P03-b-minus-s.receipt).
- [P15-walk-skip-corrected](../evidence/P15-walk-skip-corrected.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe walk-skip-v2`; [receipt](../evidence/P15-walk-skip-corrected.receipt).
- [P16-fold-skip-corrected](../evidence/P16-fold-skip-corrected.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe fold-skip-v2`; [receipt](../evidence/P16-fold-skip-corrected.receipt).
- [P24-source-census-truncation](../evidence/P24-source-census-truncation.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe census-truncation`; [receipt](../evidence/P24-source-census-truncation.receipt).
- [S3R-sorry](../evidence/S3R-sorry.log) (exit 1): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 sorry`; [receipt](../evidence/S3R-sorry.receipt).

Observation: The registered module outside the old namespace roots is built, imported and swept through just lean in S5. P02/P03 detect omitted module identities on clean outputs; P15/P16 detect one-sided T truncation naming conservation_preserved; P24 detects source/compiled omission. S3R rejects an existing non-inversion theorem poisoned with sorry while the source census remains unchanged.

Boundary: S3 was a charged setup failure before Lean, not a kill. P11/P12 targeted a wrong qualified name and are ineffective attempts, not kills. Their corrected successors supply the evidence. Valid added input must pass; omission or proof poison must fail.

## A6 — Permitted axiom policy, using-shape and transitivity

**CLOSED.** Severity: BLOCKING requirement. Method: Actual mandatory dependency rejection.

- [S1-cold-lean](../evidence/S1-cold-lean.log) (exit 0): `nix develop --quiet -c just lean`; [receipt](../evidence/S1-cold-lean.receipt).
- [S3R-sorry](../evidence/S3R-sorry.log) (exit 1): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 sorry`; [receipt](../evidence/S3R-sorry.receipt).
- [S4-axiom](../evidence/S4-axiom.log) (exit 1): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 axiom`; [receipt](../evidence/S4-axiom.receipt).

Observation: The gate extends the existing six-inversion policy [propext, Classical.choice, Quot.sound] to every discovered theorem. S4 appends auditForbidden : False, auditBridge := auditForbidden, auditDirect := auditForbidden and auditTransitive := auditBridge. It rejects exactly the direct and transitive using theorems for auditForbidden; neither a quota nor an unrelated policy failure supplies the rejection. S3R separately demonstrates sorryAx rejection.

Boundary: The inventory is thmInfo, not an audit of every unused def or axiom declaration. An unused def carrying an axiom is outside the theorem sweep; a theorem using it is covered by collectAxioms, as S4 demonstrates.

## A7 — Mandatory path and necessity

**CLOSED.** Severity: BLOCKING requirement. Method: Exact acceptance commands and poisoned gate-disable pair.

- [S1-cold-lean](../evidence/S1-cold-lean.log) (exit 0): `nix develop --quiet -c just lean`; [receipt](../evidence/S1-cold-lean.receipt).
- [S2-full-ci](../evidence/S2-full-ci.log) (exit 0): `nix develop --quiet -c just ci`; [receipt](../evidence/S2-full-ci.receipt).
- [S3R-sorry](../evidence/S3R-sorry.log) (exit 1): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 sorry`; [receipt](../evidence/S3R-sorry.receipt).
- [S4-axiom](../evidence/S4-axiom.log) (exit 1): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 axiom`; [receipt](../evidence/S4-axiom.receipt).
- [S6-poison-gate-disabled](../evidence/S6-poison-gate-disabled.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 disabled`; [receipt](../evidence/S6-poison-gate-disabled.receipt).
- [S7-symlink-relative](../evidence/S7-symlink-relative.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run relative`; [receipt](../evidence/S7-symlink-relative.receipt).

Observation: Exact just lean and just ci passed. just lean calls check-lean-axioms additively. S3R rejects the sorry body; S6 retains exactly that poison and removes only the axiom-gate recipe call, after which the full Lean recipe passes with its sorry warning and 163/163 census. S4 rejects forbidden dependencies. S7 runs the actual mandatory recipe through the declared equivalent-path setup.

Boundary: This is local execution at the frozen candidate. Parent-reported remote CI success is contextual, not independently refreshed evidence or acceptance.

## A8 — Panic detection and explicit result handling

**CLOSED.** Severity: BLOCKING requirement. Method: Actual output inspection and executable wrapper fixtures.

- [S1-cold-lean](../evidence/S1-cold-lean.log) (exit 0): `nix develop --quiet -c just lean`; [receipt](../evidence/S1-cold-lean.receipt).
- [S2-full-ci](../evidence/S2-full-ci.log) (exit 0): `nix develop --quiet -c just ci`; [receipt](../evidence/S2-full-ci.receipt).
- [P23-wrapper-controls](../evidence/P23-wrapper-controls.log) (exit 0): `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/wrapper-tests.cjs`; [receipt](../evidence/P23-wrapper-controls.receipt).

Observation: No PANIC at appeared in actual acceptance/driver logs. P23 uses the exact production suffix of each gate: a green result passes; PANIC at in stdout, PANIC at in stderr, a missing ok marker and a nonzero driver status each reject, ten cases across two wrappers. The partial getString! module-path access was replaced by a total component match and sentinel in the retained diff.

Boundary: This closes the commissioned panic-output rule, not a mathematical totality proof. The sentinel branch and every filesystem/parser exception were not separately mutated; guard-ledger entries remain OPEN where untested.

## B — Honest names, preserved computations and real enforcers (B1–B3, B5–B6)

**CLOSED.** Severity: BLOCKING requirement. Method: Compiled base comparison, executable values and diff inspection.

- [S8-base-rebuild](../evidence/S8-base-rebuild.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v6 base`; [receipt](../evidence/S8-base-rebuild.receipt).
- [P18-row-b-names](../evidence/P18-row-b-names.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe row-b`; [receipt](../evidence/P18-row-b-names.receipt).
- [P27-comparison-value-negative](../evidence/P27-comparison-value-negative.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-value-mutant`; [receipt](../evidence/P27-comparison-value-negative.receipt).
- [P29-compiled-base-comparison-complete](../evidence/P29-compiled-base-comparison-complete.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-base-v2`; [receipt](../evidence/P29-compiled-base-comparison-complete.receipt).
- [S2-full-ci](../evidence/S2-full-ci.log) (exit 0): `nix develop --quiet -c just ci`; [receipt](../evidence/S2-full-ci.receipt).
- [S6-poison-gate-disabled](../evidence/S6-poison-gate-disabled.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 disabled`; [receipt](../evidence/S6-poison-gate-disabled.receipt).

Observation: P18 finds all nine new names, rejects presence of all twelve retired identities (nine renamed plus three removed), and evaluates the three useful Bool checks true. S8 rebuilds the affected accepted-base modules from verified sources. P29 compares exact compiled Expr types and values under only the nine licensed name replacements: nine EXPR-EQUAL results. P27 changes a compared value in the real loop and receives the named i57TrustNoSorry -> admissionPreservationReachable mismatch. Docs describe admission preservation, production well-formedness/comune exclusion and comune/threshold sanity, and point trust, direction and pinning to the actual mandatory scripts. S2 runs the direction and pin self-tests; S6 demonstrates why trust needs the axiom gate. The diff explicitly avoids saying these checks are impossible in Lean. No required behavior is left to the old unrelated Bools.

Boundary: P25’s primitive Bool.true/Bool.false inequality is not credited as the loop negative control. P27 supplies actual value-branch rejection; the distinct type-mismatch branch was inspected but not independently mutated.

## B4 — Three removed TraceTests re-exports have no compiled consumers

**CLOSED.** Severity: BLOCKING requirement. Method: Rebuilt-base consumer scan with actual assertion negative.

- [S8-base-rebuild](../evidence/S8-base-rebuild.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v6 base`; [receipt](../evidence/S8-base-rebuild.receipt).
- [P28-consumer-assertion-negative](../evidence/P28-consumer-assertion-negative.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-consumer-mutant`; [receipt](../evidence/P28-consumer-assertion-negative.receipt).
- [P29-compiled-base-comparison-complete](../evidence/P29-compiled-base-comparison-complete.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-base-v2`; [receipt](../evidence/P29-compiled-base-comparison-complete.receipt).

Observation: All three removed wrappers are present in the base and absent in the candidate. P29 scans types and values, including opaque bodies, of 3385 constants in 27 project modules; two real positive references are observed, removed-wrapper consumers=0, opaque-bodies-included=0. P28 injects one in-memory reference TraceTests.checkI57Direction -> TraceTests.checkI57Trust; the same scan reports consumers=1 and the actual zero-consumer assertion rejects.

Boundary: The scan covers the stated compiled base environment, not future modules or external clients. Positive references alone were not credited as proof that the zero-consumer assertion could fail.

## C — Correct design-page comment path

**CLOSED.** Severity: BLOCKING requirement. Method: Inspection only.

Inspection/read command and retained evidence are specified below; no new execution.

Observation: Retained evidence/submission.diff changes only docs/design/state-machine.md to docs/en/design/state-machine.md in the Predicates.lean comment. No docs/ file changes in the six-file submission. Read command: cat evidence/submission.diff.

Boundary: This is a textual path correction; no claim about the design document’s semantic adequacy.

## section-5 — Root driver rule and scanner fence

**CLOSED.** Severity: BLOCKING requirement. Method: Construction/diff inspection plus actual source discovery.

- [S1-cold-lean](../evidence/S1-cold-lean.log) (exit 0): `nix develop --quiet -c just lean`; [receipt](../evidence/S1-cold-lean.receipt).
- [S5-extension-vendor](../evidence/S5-extension-vendor.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`; [receipt](../evidence/S5-extension-vendor.receipt).
- [P26-source-discovery-controls](../evidence/P26-source-discovery-controls.log) (exit 0): `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/source-discovery-tests.cjs`; [receipt](../evidence/P26-source-discovery-controls.receipt).

Observation: The shipped driver is generated in a temporary directory by scripts/check-lean-axioms; no new permanent Lean source module or Lake registration is added by this submission. The conditional new-root-module requirement is therefore not triggered. S is still every tracked/walked .lean source under lean except lakefile.lean, pruning .lake; the S5 fixture registers its added source properly and is discovered. No #70 registrations are changed.

Boundary: Construction closure of the conditional driver rule is inspection, not a separate mutation.

## AMENDMENT-1 — Quota blindness and transitive proof poison

**CLOSED.** Severity: BLOCKING requirement. Method: Mandatory execution with unchanged-count poison.

- [S3R-sorry](../evidence/S3R-sorry.log) (exit 1): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 sorry`; [receipt](../evidence/S3R-sorry.receipt).
- [S4-axiom](../evidence/S4-axiom.log) (exit 1): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 axiom`; [receipt](../evidence/S4-axiom.receipt).
- [S5-extension-vendor](../evidence/S5-extension-vendor.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`; [receipt](../evidence/S5-extension-vendor.receipt).
- [S6-poison-gate-disabled](../evidence/S6-poison-gate-disabled.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 disabled`; [receipt](../evidence/S6-poison-gate-disabled.receipt).

Observation: S3R leaves 163/163 source/backed declarations while rejecting sorryAx. The same poison passes in S6 when only the axiom gate is removed. S4 reaches transitive forbidden dependencies. S5 accepts a valid extension at 164 declarations. Together these separate actual dependency protection from the retired quota and show valid growth is permitted.


## F-001 — Former namespace-prefix extent hole

**CLOSED.** Severity: BLOCKING requirement. Method: Registered extension through mandatory path.

- [S5-extension-vendor](../evidence/S5-extension-vendor.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`; [receipt](../evidence/S5-extension-vendor.receipt).

Observation: AuditOutside.StdClean lies outside Reactivegas/KelGroups namespace prefixes, yet actual loader containment includes it: S/B=28, distinct T=1214, declared/backed=164 and its validExtension identity appears. ProjectRoots filtering is removed in the retained diff.

Boundary: The separate sibling-directory prefix concern is closed by inspected canonical trailing-separator construction, not by claiming this extension fixture tested a sibling directory.

## F-002 — One-sided compiled theorem truncation

**CLOSED.** Severity: BLOCKING requirement. Method: Corrected executable truncation controls.

- [P15-walk-skip-corrected](../evidence/P15-walk-skip-corrected.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe walk-skip-v2`; [receipt](../evidence/P15-walk-skip-corrected.receipt).
- [P16-fold-skip-corrected](../evidence/P16-fold-skip-corrected.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe fold-skip-v2`; [receipt](../evidence/P16-fold-skip-corrected.receipt).

Observation: P15 rejects walk-distinct=1212/fold=1213 and names conservation_preserved missing from the module walk. P16 rejects 1213/1212 and names it missing from the constant fold. There are two related diagnostics per run; no unrelated axiom finding. P11/P12 earlier passed because the wrong qualified identity was targeted, and receive no kill credit.

Boundary: No sole-necessity claim for the count diagnostic: finite set cardinality mismatch entails some identity difference. Shared nonzero shrink in both views is the expressly bounded CI-T-SHARED-FILTER advisory.

## F-003 — Project ownership must not be import-Lean closure

**CLOSED.** Severity: BLOCKING requirement. Method: Vendor and Std extension execution with resolved path readback.

- [S5-extension-vendor](../evidence/S5-extension-vendor.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`; [receipt](../evidence/S5-extension-vendor.receipt).
- [P13-vendor](../evidence/P13-vendor.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe vendor`; [receipt](../evidence/P13-vendor.receipt).
- [P17-independent-extent](../evidence/P17-independent-extent.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe extent`; [receipt](../evidence/P17-independent-extent.receipt).

Observation: The extension imports Std.Data.DHashMap and remains project-owned while vendor modules resolve outside the canonical root. P17 records 262 excluded Std modules and exact resolved paths. P13’s vendor-first baseline reproduces baseline identities. No import-Lean closure or module-name whitelist is used by the candidate resolver.

Boundary: Does not establish classification for dependencies whose real outputs live inside the repository. See Element 2.

## F-004 — Resolved canonical paths rather than lexical spellings

**CLOSED.** Severity: BLOCKING requirement. Method: Actual equivalent-path driver inputs.

- [S5-extension-vendor](../evidence/S5-extension-vendor.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`; [receipt](../evidence/S5-extension-vendor.receipt).
- [S7-symlink-relative](../evidence/S7-symlink-relative.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run relative`; [receipt](../evidence/S7-symlink-relative.receipt).
- [P13-vendor](../evidence/P13-vendor.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe vendor`; [receipt](../evidence/P13-vendor.receipt).
- [P14-relative](../evidence/P14-relative.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe relative`; [receipt](../evidence/P14-relative.receipt).
- [P20-interceptor-transparent](../evidence/P20-interceptor-transparent.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/transparency`; [receipt](../evidence/P20-interceptor-transparent.receipt).
- [P21-build-forwarding](../evidence/P21-build-forwarding.log) (exit 0): `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/forwarding-test.cjs`; [receipt](../evidence/P21-build-forwarding.receipt).

Observation: Vendor alias paths canonicalize outside the root. S7 supplies relative loader entries after Lake sets its environment and invokes through the symlinked worktree alias; S/B=27, T=1213, source/backed=163 remain unchanged. LOADER-INPUT receipts record the effective inputs to both production drivers. P20 forwards the actual driver and preserves baseline bytes after its receipt line; P21 tests exact build argv forwarding and detects a deliberately dropped argument.

Boundary: An outer LEAN_PATH assignment alone is not credited because Lake can replace it. P21 uses an argument recorder for build forwarding; S5/S7 additionally execute the real builds. No universal claim about all filesystem layouts.

## G-001 — Retained empty/unset LEAN_PATH authority guard

**CLOSED.** Severity: BLOCKING requirement. Method: Two distinct direct elaborations.

- [P07-empty](../evidence/P07-empty.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe empty`; [receipt](../evidence/P07-empty.receipt).
- [P08-unset](../evidence/P08-unset.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe unset`; [receipt](../evidence/P08-unset.receipt).

Observation: Empty and unset LEAN_PATH each yield exactly ownership authority missing: LEAN_PATH empty or unset, with exit 1. The minimal import-Lean instrument reaches the unchanged guard before project imports could fail for another reason. The branch is retained, not retired.

Boundary: The operative A-003 contract requires direct elaboration, not a whole build. This does not establish the different REACTIVEGAS_ROOT missing-variable claim.

## Element-1 — Ownership authority, canonicalization and documented fail-closed behavior

**PARTLY.** Severity: BLOCKING behavior established; ADVISORY documentation finding OPEN. Method: Runtime readback plus inspected driver/header mismatch.

- [P17-independent-extent](../evidence/P17-independent-extent.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe extent`; [receipt](../evidence/P17-independent-extent.receipt).
- [P22-unset-root](../evidence/P22-unset-root.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/unset-root`; [receipt](../evidence/P22-unset-root.receipt).
- [P07-empty](../evidence/P07-empty.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe empty`; [receipt](../evidence/P07-empty.receipt).
- [P08-unset](../evidence/P08-unset.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe unset`; [receipt](../evidence/P08-unset.receipt).

Observation: The operative ownership rule and canonicalization are established for the current configuration. LEAN_PATH absence rejects. However P22 unsets REACTIVEGAS_ROOT and the direct production driver accepts the baseline from cwd=lean: getD "." supplies a default. The shipped header claims missing/unresolvable REACTIVEGAS_ROOT fails closed. The missing-variable portion of that claim is false and remains OPEN.

Boundary: Advisory documentation finding owned by the commissioning owner for disposition with the implementation owner; not a demonstrated mandatory-path bypass because the shell exports REACTIVEGAS_ROOT. No candidate edit or new execution requested.

## Element-2 — Current source/output relation and root-containment boundary

**CLOSED.** Severity: BLOCKING requirement. Method: Current compiled path evidence and recorded configuration inspection.

- [S1-cold-lean](../evidence/S1-cold-lean.log) (exit 0): `nix develop --quiet -c just lean`; [receipt](../evidence/S1-cold-lean.receipt).
- [S5-extension-vendor](../evidence/S5-extension-vendor.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`; [receipt](../evidence/S5-extension-vendor.receipt).
- [P17-independent-extent](../evidence/P17-independent-extent.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe extent`; [receipt](../evidence/P17-independent-extent.receipt).

Observation: S/B reconciliation associates current source module identities with environment modules resolved to real artifacts inside the canonical repository root. Recorded NOTE-004 inspection confirms lakefile has no require, manifest packages=[], and .lake/packages absent. All observed dependencies resolve outside the root. This establishes the current-source/current-loader relation.

Boundary: NOTE-004 is not a present implementation finding: there is no materialized in-root dependency to misclassify. It is a physical-layout assumption, not universal package-origin proof. A dependency materialized physically under .lake/packages would satisfy containment; no package-specific source-origin binding or carve-out exists. Future dependency-layout changes need an owner decision; no hidden new invariant or test is imposed here.

## Element-3 — Equivalent loader paths

**CLOSED.** Severity: BLOCKING requirement. Method: Mandatory and direct controls.

- [S5-extension-vendor](../evidence/S5-extension-vendor.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`; [receipt](../evidence/S5-extension-vendor.receipt).
- [S7-symlink-relative](../evidence/S7-symlink-relative.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run relative`; [receipt](../evidence/S7-symlink-relative.receipt).
- [P13-vendor](../evidence/P13-vendor.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe vendor`; [receipt](../evidence/P13-vendor.receipt).
- [P14-relative](../evidence/P14-relative.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe relative`; [receipt](../evidence/P14-relative.receipt).
- [P20-interceptor-transparent](../evidence/P20-interceptor-transparent.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/transparency`; [receipt](../evidence/P20-interceptor-transparent.receipt).
- [P21-build-forwarding](../evidence/P21-build-forwarding.log) (exit 0): `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/forwarding-test.cjs`; [receipt](../evidence/P21-build-forwarding.receipt).

Observation: Relative and aliased vendor entries, symlinked cwd, and absolute baseline classify the same corresponding identities. S5’s extra module is the intentional denominator change; S7/P13/P14 retain baseline identities. Instrument transparency and actual driver input are separately evidenced.

Boundary: Equivalent spelling tests do not stand in for the physically in-root dependency layout in NOTE-004.

## Element-4 — Clean independent omissions; owner contamination question

**CLOSED.** Severity: BLOCKING requirement. Method: Unmasked red/guard-disabled-green pairs.

- [P02-s-minus-b](../evidence/P02-s-minus-b.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe s-minus-b`; [receipt](../evidence/P02-s-minus-b.receipt).
- [P03-b-minus-s](../evidence/P03-b-minus-s.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe b-minus-s`; [receipt](../evidence/P03-b-minus-s.receipt).
- [P04-s-minus-b-disabled](../evidence/P04-s-minus-b-disabled.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe s-minus-b-disabled`; [receipt](../evidence/P04-s-minus-b-disabled.receipt).
- [P05-b-minus-s-disabled](../evidence/P05-b-minus-s-disabled.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe b-minus-s-disabled`; [receipt](../evidence/P05-b-minus-s-disabled.receipt).

Observation: The owner’s P26/P27 omission logs had an unrelated stale poisoned-CorpusGate axiom finding; their nonzero aggregate exits do not establish guard necessity. This auditor’s differently numbered P02/P03 each contain only the intended omission finding on clean artifacts; P04/P05 remove only the relevant guard and pass. The owner’s historical logs remain contaminated; they are neither rewritten nor retroactively cleaned. The current obligation is closed by independent evidence.

Boundary: Owner P26/P27 must not be confused with this auditor’s P26 discovery fixtures/P27 comparator negative. These are direct-driver controls under A-001 as reinstated and clarified by A-003.

## Element-5 — Missing-authority retained-versus-retired decision

**CLOSED.** Severity: BLOCKING requirement. Method: Retained branch exercised.

- [P07-empty](../evidence/P07-empty.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe empty`; [receipt](../evidence/P07-empty.receipt).
- [P08-unset](../evidence/P08-unset.log) (exit 1): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe unset`; [receipt](../evidence/P08-unset.receipt).

Observation: The implementation retains the LEAN_PATH empty/unset branch and both direct elaborations reject for that exact cause. The lawful retained-branch option is established; no authority-replacement or branch-retirement claim is made.

Boundary: S9/S10 whole-build proposals were withdrawn before execution, not spent or refunded.

## Integration — Accepted exporter integration at this candidate

**CLOSED.** Severity: BLOCKING requirement. Method: Cold inventory and exact full local CI.

- [S1-cold-lean](../evidence/S1-cold-lean.log) (exit 0): `nix develop --quiet -c just lean`; [receipt](../evidence/S1-cold-lean.receipt).
- [S2-full-ci](../evidence/S2-full-ci.log) (exit 0): `nix develop --quiet -c just ci`; [receipt](../evidence/S2-full-ci.receipt).
- [P17-independent-extent](../evidence/P17-independent-extent.log) (exit 0): `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe extent`; [receipt](../evidence/P17-independent-extent.receipt).
- [S8-base-rebuild](../evidence/S8-base-rebuild.log) (exit 0): `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v6 base`; [receipt](../evidence/S8-base-rebuild.receipt).

Observation: CorpusExport is the 27th discovered project module, registered in the accepted base. The actual full CI command passes its corpus gate and verification as well as the mandatory Lean path. The rebuilt-base consumer import inventory also contains CorpusExport. Exporter changes in the 4a6-to-candidate aggregate diff are accepted-base integration, not unauthorized edits by the S2R submission.

Boundary: This commission does not repeat PR87’s exporter mutation campaign. Parent-reported remote runs 33970297094/33970297155 are context only; no remote state refreshed during closeout.

## Provenance-and-fence — Frozen candidate, diff fence, authority and spend

**CLOSED.** Severity: BLOCKING requirement. Method: Retained provenance/authority receipts and invocation accounting.

Inspection/read command and retained evidence are specified below; no new execution.

Observation: Candidate 714cb2a8536b24bf735295137e8f907782228380 is detached over d67032313acf3699cc50358a057391b88d002192. Retained final-git-provenance.txt records clean status and six changed files: justfile, three licensed Lean files and two scripts. submission.diff is the six-file delta; candidate.diff includes the accepted exporter chain from 4a6. Base source comparison is licensed by identical three Row B blobs across 4a6 and d670323. Initial START is not renewed by the seat release. Nine substantive and 29 targeted receipts remain charged, including failed setup/ineffective attempts. Read commands: cat evidence/final-git-provenance.txt; cat evidence/submission.diff; cat evidence/base-blob-equality.txt; read STATUS.md invocation records.

Boundary: No candidate re-verification or campaign execution after NOTE-006. Clean-state claims cite the retained receipts rather than claiming a newly run Git check. Accepted S1 fa01779 was not a rejected S2; rejected S2 candidates are exactly 5745a2c, 561347d, b0c2cdb.

## Guard attribution ledger

These are classifications of existing guards, not a new execution campaign. OPEN untested branches are not credited as measured failures. Construction-only closure means the stated reachability/redundancy argument, not a passed mutation. Mandatory row closure is restricted to its commissioned observable scope.

| Existing guard or branch | Verdict | Evidence | Observation / limit |
|---|---|---|---|
| Source tracked/walked agreement and both shell zero branches | CLOSED | P26 | Exact axiom-script prefix on a real git fixture; positive passes, each named omission/zero rejects. Inversion-script matching prefix inspected, not separately executed on fixtures. |
| S-minus-B / B-minus-S | CLOSED | P02,P03,P04,P05 | One sole finding each, then same defective input passes with only its guard disabled. |
| S/B/T nonzero inside driver | CLOSED | P06,P09,P10 | S and B controls explicitly disable companion guards; T-zero isolates both producers. |
| T identity differences, both directions | CLOSED | P15,P16 | Each intended missing identity rejected; count diagnostic co-fires. |
| T count mismatch as a sole finding | CLOSED | Inspection of retained submission.diff | Construction classification only: differing finite deduplicated set cardinalities entail some identity difference, so count-only isolation is not independent protection. No sole-necessity execution claimed. |
| Theorem disappears after theoremsByWalk selection | CLOSED | Inspection of retained submission.diff | Construction classification only: walk accepts thmInfo from env.find?; the same immutable environment is consulted later without an intervening declaration change. The fallback is defensive, not observed failing. |
| Forbidden dependency / sorryAx | CLOSED | S3R,S4,S6 | Dependency rejection reached; poisoned gate-disabled mandatory path passes. |
| LEAN_PATH empty / unset | CLOSED | P07,P08 | Two separate direct elaborations, sole guard finding. |
| REACTIVEGAS_ROOT missing fails closed | OPEN | P22 | Counterexample observed: unset variable defaults to cwd and accepts. Advisory documentation mismatch under Element 1. |
| Root canonicalization exception | OPEN | No execution receipt | Inspected error recording only; not independently exercised. No claim it has been observed to reject. |
| Resolved artifact canonicalization exception | OPEN | No execution receipt | Helper catch returns false; eventual S/B consequence depends on the module. No independent branch execution or universal fail-closed claim. |
| Environment module has no loadable artifact | OPEN | No execution receipt | Recorded-error branch inspected, not exercised; ordinary import resolution usually occurs before the driver. |
| Source path canonicalization and non-string module sentinel | OPEN | No execution receipt | Inspected total branches; no isolated runtime negative. |
| Source/compiled theorem missing identity and census mismatch | CLOSED | P24 | Named missing source-backed identity and 163/162 disagreement; redundant diagnostics not separately attributed. |
| Source/backed zero census guards and wrong-name branch | OPEN | No dedicated negative receipt | Present by inspection; positive census and omission tested. Not promoted to separately executed guard coverage. |
| PANIC stdout/stderr, nonzero status, missing ok marker | CLOSED | P23 | Exact suffix from both production wrappers, positive and eight rejecting fixtures. Synthetic panic output is intentional. |
| Comparator value mismatch | CLOSED | P27 | Same comparison loop rejects the named altered value. Primitive preliminary inequality alone is not sufficient. |
| Comparator type mismatch independently | OPEN | No dedicated negative receipt | P29 compares actual types, but only value-mismatch rejection was directly challenged. |
| Zero removed-wrapper consumers | CLOSED | P28,P29 | Same scan/assertion rejects one injected reference and accepts complete clean extent with zero references. |
| Inherited six-inversion failure branches | PARTLY | S1,S2,P24; retained diff | Six obligations retained and run, plus withheld-backdonate negative; not a fresh separate mutation of every inherited failure branch. |
| Usage, missing source directory and build failure wrappers | OPEN | No dedicated control receipt | Ordinary setup/error propagation inspected; S3 is a harness setup failure, not credited as a gate build-error control. |

## Failed attempts, integrity and stopping receipt

S3 is a substantive setup failure: the original Bubblewrap launcher omitted /dev/null access, and the dependency scanner failed before Lean. It remains charged and has no kill credit. A-003 authorized exactly one replacement. The failed launcher/cache were retained; the corrected v4 launcher and narrow mount preflight preceded S3R. P11/P12 are charged ineffective mutations using the wrong qualified theorem name; P15/P16 correct them. P19 is only an instrument preflight. P25 retains its actual positive observations with its inadequate preliminary-negative characterization corrected by P27/P28. These distinctions remain in EXECUTION-LEDGER.md.

The admitted manifest originally included itself and failed its self-hash; the documents themselves matched. NOTE-003's corrected 17-entry manifest verified, as recorded in evidence/admitted-manifest-recheck.txt. Both historical receipts remain. The frozen owner packet matched at admission; no moving live packet was substituted. Earlier rejected candidate results provide no closure evidence.

Mutation builds used private mounted fixture sources and separate output caches. The preserved clean-oleans recheck records the candidate outputs unchanged; final-git-provenance.txt and the operator-pause receipt record the candidate detached and clean. These are retained observations, not freshly rerun claims after release. All 38 individual invocation receipts, logs and failed instruments are preserved. The older receipts.json/observed-output-audit.json snapshots predate P27–P29; the completed execution ledger incorporates the individual later receipts without rewriting history.

Campaign stopped at its completed named control set, with 9/9 substantive and 29/30 targeted spent. Reporting-only release used no execution allowance. No new gap was pursued, no scope expansion requested, and no remaining slot spent. Monetary/token counters are not available in these execution receipts and are not inferred.

Handoff: this report, ROW-LEDGER.md/json, EXECUTION-LEDGER.md/json, refreshed INSTRUMENTS.sha256, EVIDENCE.sha256, AUTHORITY.sha256, and HASH-HANDOFF.md. FINAL.sha256 binds the terminal documents/manifests; it excludes itself to avoid self-reference. STATUS.md remains append-only and its terminal event carries report and final-manifest hashes. Acceptance and any onward correction belong to the commissioning owner. All artifacts, caches and the pane remain preserved.
