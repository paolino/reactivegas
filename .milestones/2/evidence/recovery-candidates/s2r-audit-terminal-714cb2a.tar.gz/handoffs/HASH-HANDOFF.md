# Final local hash handoff

Verdict: **AUDIT-FINDINGS**. Candidate: `714cb2a8536b24bf735295137e8f907782228380`.

Report: [AUDIT-REPORT.md](AUDIT-REPORT.md), SHA-256 `d634df52c51d4351699d36927b5b0c662357a4ac08a7d689a6708db2d34def90`.

25 integrated rows: 24 CLOSED, 1 PARTLY. Element 1 retains one OPEN advisory documentation finding: missing REACTIVEGAS_ROOT defaults to cwd despite the header's fail-closed claim. No blocking functional defect demonstrated in the commissioned current-configuration behavior. NOTE-004 containment is a stated physical-layout assumption, not a present defect. NOTE-005 comparator/assertion limits are closed by P27/P28, with P29 the final complete scan. Untested auxiliary guard branches remain explicitly OPEN; no universal coverage claim.

Deliverables:

- [ROW-LEDGER.md](ROW-LEDGER.md) and [ROW-LEDGER.json](ROW-LEDGER.json): integrated decisions, commands, observations and guard limits.
- [EXECUTION-LEDGER.md](EXECUTION-LEDGER.md) and [EXECUTION-LEDGER.json](EXECUTION-LEDGER.json): all 38 preserved command/exit/hash receipts, including charged failures.
- [INSTRUMENTS.sha256](INSTRUMENTS.sha256): 114 regular instrument/fixture files, refreshed through P29. The earlier manifest is retained as INSTRUMENTS-pre-closeout.sha256.
- [INSTRUMENT-SYMLINKS.json](INSTRUMENT-SYMLINKS.json): 0 symbolic-link path/target records; symlink targets are not recursively hashed by this instrument manifest.
- [EVIDENCE.sha256](EVIDENCE.sha256): 103 retained evidence files, including every individual P27–P29 receipt/log.
- [AUTHORITY.sha256](AUTHORITY.sha256): 31 frozen/current authority and Q/A files. Superseded documents remain historical, not simultaneously operative.
- [STATUS-PRE-HANDOFF.log](STATUS-PRE-HANDOFF.log): immutable journal snapshot before terminal events; live STATUS.md stays append-only.
- [FINAL.sha256](FINAL.sha256): hashes of final documents, reporting scripts, snapshot and component manifests; excludes itself. Its hash is recorded in the terminal STATUS event.

Manifest paths are relative to the runtime root:
`/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex`.
For document/package verification only, use `sha256sum -c handoffs/FINAL.sha256` from that root; component manifests bind their listed files. This does not execute or revalidate any candidate control. These commands are instructions for reviewing the package, not an added campaign.

Release acknowledged: NOTE-006 / RELEASE-STORIES-20260905. Same seat/context; no fresh START, cap refund or new execution. Spend **9/9 substantive; 29/30 targeted**, unchanged. The unused targeted slot remains unused. Original receipt snapshots predating P27–P29 are retained unchanged; the final execution ledger uses individual receipts.

Candidate, worktree, caches, fixtures, failed attempts and pane preserved. No new build/probe, candidate edit, outward message, publication, push, PR action, merge or cleanup. This handoff completes the auditor's report obligation; acceptance and any follow-up authorization belong to the commissioning owner. No further work is queued by this seat.
