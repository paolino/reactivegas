# Preserved execution ledger — no reruns

9 substantive / 9; 29 targeted / 30. Failed, warm and ineffective attempts remain charged. All 38 individual receipts are included; the older evidence/receipts.json snapshot predates P27–P29 and is preserved unchanged.

## P01-environment

Class: targeted; exit 0; duration 1354 ms.

Command: `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/setup.sh`

Command SHA-256: `ee2c79c5041fecd1a754036b5336d10d07e1c932b53bb0da800f7798dd37439c`

Output SHA-256: `7ffc67c66b289e25cfc639dfbbb232981634c42d51b201c753aceeef04105d1f`; [log](../evidence/P01-environment.log); [receipt](../evidence/P01-environment.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P02-s-minus-b

Class: targeted; exit 1; duration 12434 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe s-minus-b`

Command SHA-256: `2e65b5dcdbeed70129fdbf1ca0970fd5c93cb5fb941bb553bd4ab506e96d07db`

Output SHA-256: `0aa8b45626e9c5a58a16c11fabcb045baa75f4d531fa61ba3bebd341cbb4904c`; [log](../evidence/P02-s-minus-b.log); [receipt](../evidence/P02-s-minus-b.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P03-b-minus-s

Class: targeted; exit 1; duration 12787 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe b-minus-s`

Command SHA-256: `b23766344f9219a4433c54181f30a5fea70608e5e85da43fd96efbf2bb964fae`

Output SHA-256: `cc3d11769342973447ba732e8df81633782a4d3b4d772d3ef19512a30da3c692`; [log](../evidence/P03-b-minus-s.log); [receipt](../evidence/P03-b-minus-s.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P04-s-minus-b-disabled

Class: targeted; exit 0; duration 12135 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe s-minus-b-disabled`

Command SHA-256: `b1d15d6bffe1835427d4c1ebad1c45ee4b47bd0c68bcfa798ee651f6b4496e12`

Output SHA-256: `77d8f43f7ddbf59e60052121b434c007a144e62b4b8eceea88e595cd8d17939e`; [log](../evidence/P04-s-minus-b-disabled.log); [receipt](../evidence/P04-s-minus-b-disabled.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P05-b-minus-s-disabled

Class: targeted; exit 0; duration 12694 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe b-minus-s-disabled`

Command SHA-256: `33bada47bfd85b85f72a041d9a9e1858ad8c2738d37d26f8b03b95b3e8c22cbf`

Output SHA-256: `cacc8364c2c3a02b760ac3e6750a4dd8662465dc27697364cddfa9c10edcfd73`; [log](../evidence/P05-b-minus-s-disabled.log); [receipt](../evidence/P05-b-minus-s-disabled.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P06-tzero

Class: targeted; exit 1; duration 2286 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe tzero`

Command SHA-256: `0c8d5a4ae32a9e83c34d07b47300df266728552a9f6e854887ecb4283d1a2cdc`

Output SHA-256: `7abdca4f7673f1178f3725c068376f8abe6a1eb917392cf7f1ba3ff4d0e7eab0`; [log](../evidence/P06-tzero.log); [receipt](../evidence/P06-tzero.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P07-empty

Class: targeted; exit 1; duration 2290 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe empty`

Command SHA-256: `ae437c8d6868cecc9fbcb86e37c248ed0ae9bffc19e3ffd30bd96e1e223ae4af`

Output SHA-256: `5c89a5919f167dc2a317f2b5d951c25dce4634a8a5966df16232cf315a786084`; [log](../evidence/P07-empty.log); [receipt](../evidence/P07-empty.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P08-unset

Class: targeted; exit 1; duration 2361 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe unset`

Command SHA-256: `75b3758d55b423b01fa2130e60bfaac54773d7aa6928f3210b2d4405f946beef`

Output SHA-256: `5c89a5919f167dc2a317f2b5d951c25dce4634a8a5966df16232cf315a786084`; [log](../evidence/P08-unset.log); [receipt](../evidence/P08-unset.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P09-szero

Class: targeted; exit 1; duration 12813 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe szero-isolated`

Command SHA-256: `734283662e4879942b3797a0ae6049a5d4bb9ed76e5b0d8cd05dadc2e745091b`

Output SHA-256: `d14acdd1a66a6c6a758939d4777d8455693d074c696a2ca29937036ab1463cd1`; [log](../evidence/P09-szero.log); [receipt](../evidence/P09-szero.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P10-bzero

Class: targeted; exit 1; duration 4673 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe bzero-isolated`

Command SHA-256: `aa8994cc28e2bcb719aa0a20f989266a934f38ed79fd2622a9ed8ba7798227e2`

Output SHA-256: `66e7af644a37ac979c8f3784495da0e8dc5097d4c8844c0cd6a10ebc11f2aa6d`; [log](../evidence/P10-bzero.log); [receipt](../evidence/P10-bzero.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P11-walk-skip

Class: targeted; exit 0; duration 12861 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe walk-skip`

Command SHA-256: `9e3ea575fb87d6f9290d66d1ce5827f52c26d1a3a60839ce8a55f5b62e5366ae`

Output SHA-256: `5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161`; [log](../evidence/P11-walk-skip.log); [receipt](../evidence/P11-walk-skip.receipt).

INEFFECTIVE MUTATION, charged; wrong qualified name, no kill credit; corrected by P15.

## P12-fold-skip

Class: targeted; exit 0; duration 12707 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe fold-skip`

Command SHA-256: `46c9ad30a026bdb597ac249a72d86ca95de86378899f7c34190dabe917756471`

Output SHA-256: `5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161`; [log](../evidence/P12-fold-skip.log); [receipt](../evidence/P12-fold-skip.receipt).

INEFFECTIVE MUTATION, charged; wrong qualified name, no kill credit; corrected by P16.

## P13-vendor

Class: targeted; exit 0; duration 12724 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe vendor`

Command SHA-256: `1896569a6fa029091d0e714524c16880ae2cbbf8f40cb34f5e4dffe524dfe7a1`

Output SHA-256: `5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161`; [log](../evidence/P13-vendor.log); [receipt](../evidence/P13-vendor.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P14-relative

Class: targeted; exit 0; duration 12776 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe relative`

Command SHA-256: `e1deb223506f4f5644d2749a7d94f1c9f291cbacf8ac683204f7e9a093ad7c87`

Output SHA-256: `5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161`; [log](../evidence/P14-relative.log); [receipt](../evidence/P14-relative.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P15-walk-skip-corrected

Class: targeted; exit 1; duration 12515 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe walk-skip-v2`

Command SHA-256: `d64886d9fb0670f5bfc9765b9a66b3157a781fb394ca830ab543ceaa8d539b44`

Output SHA-256: `d41eb769e9fcc94e34827784e28623ce09bd9b812912f3beb8483234afb31ec6`; [log](../evidence/P15-walk-skip-corrected.log); [receipt](../evidence/P15-walk-skip-corrected.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P16-fold-skip-corrected

Class: targeted; exit 1; duration 12722 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe fold-skip-v2`

Command SHA-256: `874ee11cf21e3b7c6ac7c139e68c6ebd3e233fa944b3a22f50fcce0473bd77af`

Output SHA-256: `11a8da762101ad002b6e2a73d6b6c2059fb68a5870406afcb83e1c4d277daf7c`; [log](../evidence/P16-fold-skip-corrected.log); [receipt](../evidence/P16-fold-skip-corrected.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P17-independent-extent

Class: targeted; exit 0; duration 2559 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe extent`

Command SHA-256: `34f81536eec4f548df4f832f9510a9298ca46672aaa37e6627b512ee21a54f59`

Output SHA-256: `ef046ae5220e95c6703f0da4891775857a5930be30477f91d8f504f7a5af22cb`; [log](../evidence/P17-independent-extent.log); [receipt](../evidence/P17-independent-extent.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P18-row-b-names

Class: targeted; exit 0; duration 2135 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe row-b`

Command SHA-256: `e985ae991f115c354062c090874c9ca8148a42c67c5e201cc97cf461ac935fd1`

Output SHA-256: `fabbc42a0e412d969f0804c6fbae0a235f06062380dd6d7d98b86531a7375b11`; [log](../evidence/P18-row-b-names.log); [receipt](../evidence/P18-row-b-names.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P19-compare-preflight

Class: targeted; exit 0; duration 1437 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-preflight`

Command SHA-256: `a0e0e840bd90001e5df8e8caecbf2e491165a65ebefabc4d9bf92a948575fd1c`

Output SHA-256: `28769f3e17b8eaba6570ee406518efbdccd623c1a368e84b8e0180fb0ce47cd7`; [log](../evidence/P19-compare-preflight.log); [receipt](../evidence/P19-compare-preflight.receipt).

Instrument typecheck only; not base comparison evidence.

## P20-interceptor-transparent

Class: targeted; exit 0; duration 13268 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/transparency`

Command SHA-256: `65fcb539617a38f3d1e0a2ad4cc458a1ffe80e650e5ed21abd1071b0488d5c71`

Output SHA-256: `0c85097b589aab27579b0a986db6ffc0de47718250d6b804eca2d71a974dba45`; [log](../evidence/P20-interceptor-transparent.log); [receipt](../evidence/P20-interceptor-transparent.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P21-build-forwarding

Class: targeted; exit 0; duration 160 ms.

Command: `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/forwarding-test.cjs`

Command SHA-256: `0b1a8a2a6f4b38bb9936d6c3ad441fdee59db234a5d7a75f311c054bc66891b7`

Output SHA-256: `d1df302314ee41da77e31a54cb30a9468c41b844918ee0b66578e5d99aa1b179`; [log](../evidence/P21-build-forwarding.log); [receipt](../evidence/P21-build-forwarding.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P22-unset-root

Class: targeted; exit 0; duration 12758 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/unset-root`

Command SHA-256: `b3dad9e20dbb3aaeaed785a9e06853bd551153a51b3eebe62ed8fea8de50c9e6`

Output SHA-256: `5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161`; [log](../evidence/P22-unset-root.log); [receipt](../evidence/P22-unset-root.receipt).

Observed counterexample to missing-root documentation claim, not mandatory-path bypass.

## P23-wrapper-controls

Class: targeted; exit 0; duration 247 ms.

Command: `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/wrapper-tests.cjs`

Command SHA-256: `370e041b02a9eef213778578de8e4db6c2acfea19ed427cdf05d6c603207802a`

Output SHA-256: `68e5602ef4a53e4c875f9b820e3946614f83e8054728487da35c5c855026172d`; [log](../evidence/P23-wrapper-controls.log); [receipt](../evidence/P23-wrapper-controls.receipt).

Shell fixture harness exit 0 means expected accept/reject results matched; includes deliberate synthetic panic strings.

## P24-source-census-truncation

Class: targeted; exit 1; duration 4866 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe census-truncation`

Command SHA-256: `8d8134fced6d4eef17f53c4e776c5d167afbebd1e42ee91d672a9f415b6e7d02`

Output SHA-256: `9cc8a8bbba4eaab6b32247c7c6e3f7c1354fd9a6b72e1ce7ea805dbf0937b633`; [log](../evidence/P24-source-census-truncation.log); [receipt](../evidence/P24-source-census-truncation.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P25-compiled-base-comparison

Class: targeted; exit 0; duration 12047 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-base`

Command SHA-256: `6b64c2cb3b3a4211e4d7aa0356e33770f59ad3f98abadcf6301921912b7c099c`

Output SHA-256: `81243c9481bbcc06f1fd9ad59cf7ec56c95bbb44490f3cffe9a33cf5a91cd220`; [log](../evidence/P25-compiled-base-comparison.log); [receipt](../evidence/P25-compiled-base-comparison.receipt).

Original positive comparisons stand; preliminary primitive inequality did not test loop rejection. P27/P28 and final P29 close the stated instrument limits.

## P26-source-discovery-controls

Class: targeted; exit 0; duration 249 ms.

Command: `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/source-discovery-tests.cjs`

Command SHA-256: `1a06902adf4aef2631ab21faa6e59d6556eddb3c11245114ee68248911e9f377`

Output SHA-256: `fca592877def814a75b3ca568e4f37f4cf67951ff6cd16148251bfe36954a6c5`; [log](../evidence/P26-source-discovery-controls.log); [receipt](../evidence/P26-source-discovery-controls.receipt).

Shell fixture harness exit 0 means expected accept/reject results matched; no Lean/build.

## P27-comparison-value-negative

Class: targeted; exit 1; duration 6177 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-value-mutant`

Command SHA-256: `8327be2095e967a043ec3dbb455f127265a0305aae0e6037019490f9aa9879a3`

Output SHA-256: `ad9598cd6250a2a63f1d4447f6d331e8dfc2d02139b45df3781a089bf7fbb5c8`; [log](../evidence/P27-comparison-value-negative.log); [receipt](../evidence/P27-comparison-value-negative.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P28-consumer-assertion-negative

Class: targeted; exit 1; duration 9965 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-consumer-mutant`

Command SHA-256: `51bf4f0e3d63235c3df8bffac6d9c68044e7b8f5ff788cdcb3de7866c735048a`

Output SHA-256: `d6512d0ad849b4bb1539a9a9ca8403e9fca39ab2d75c8c5df109d25ce3542017`; [log](../evidence/P28-consumer-assertion-negative.log); [receipt](../evidence/P28-consumer-assertion-negative.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## P29-compiled-base-comparison-complete

Class: targeted; exit 0; duration 9848 ms.

Command: `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-base-v2`

Command SHA-256: `551f11ee79a638ee75fa94f3e6d0ac0833e9528ebcf40ea5dd3d3769fdc30d27`

Output SHA-256: `85c366f184033f0cd840afa5f696d5531fb6d4527dff96f9c9c7b1bfd002d96a`; [log](../evidence/P29-compiled-base-comparison-complete.log); [receipt](../evidence/P29-compiled-base-comparison-complete.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## S1-cold-lean

Class: substantive; exit 0; duration 70563 ms.

Command: `nix develop --quiet -c just lean`

Command SHA-256: `53fd5545f7b6a6afa05379fa86392cc4d3f839e6b89e9065a4ebe8cb91bec064`

Output SHA-256: `f5671e859a96f4124608029b21b6ef0f7b8b427b61abe20288bf92b2e05a7989`; [log](../evidence/S1-cold-lean.log); [receipt](../evidence/S1-cold-lean.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## S2-full-ci

Class: substantive; exit 0; duration 138877 ms.

Command: `nix develop --quiet -c just ci`

Command SHA-256: `1f96c71604d37c665a69211b9ccd9656b76fd324d6278ff3fa17c289c371a5b2`

Output SHA-256: `e15cef111aa980a2919ee9f233e4ffa87294258b1d1c2d0e22f1cd73e3bd1463`; [log](../evidence/S2-full-ci.log); [receipt](../evidence/S2-full-ci.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## S3-sorry

Class: substantive; exit 1; duration 1026 ms.

Command: `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run sorry`

Command SHA-256: `676b38949ddda8548a3dc82dc1d403f23dcf2ba987594083f00a876de03d7ab8`

Output SHA-256: `a4ae770a617f8e8617137f6044a676efff959d4d2407aad74e2a16b5ebe5bca1`; [log](../evidence/S3-sorry.log); [receipt](../evidence/S3-sorry.receipt).

SETUP FAILURE, charged; /dev/null inaccessible before Lean; no mutation-kill credit.

## S3R-sorry

Class: substantive; exit 1; duration 48100 ms.

Command: `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 sorry`

Command SHA-256: `c211d0117da0027d898449a28a3e50b662774a178daf85a49bbc8d86163ea83a`

Output SHA-256: `ec8bfcc1e8107d94b9e5e7b25bcf0d4dbbdcd3d4b8e456a765e8a94a7dd6c1f3`; [log](../evidence/S3R-sorry.log); [receipt](../evidence/S3R-sorry.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## S4-axiom

Class: substantive; exit 1; duration 27432 ms.

Command: `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 axiom`

Command SHA-256: `a11849b9d3ea46f6c7890efbc7ee874e484e6b49430fbdfb10b476897d9824f4`

Output SHA-256: `dd5e582500b533acd4937e27310453ac4c64213ce5065387ac1da10c9a14be49`; [log](../evidence/S4-axiom.log); [receipt](../evidence/S4-axiom.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## S5-extension-vendor

Class: substantive; exit 0; duration 44344 ms.

Command: `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor`

Command SHA-256: `6900e1cb0e0ac67a43de0c73b44a27e92aa5e40e5fcd74d14afee52ce82dd4db`

Output SHA-256: `bb117088f4a823dd964950a7290e298b978a507a9ba70a677241053d94c43599`; [log](../evidence/S5-extension-vendor.log); [receipt](../evidence/S5-extension-vendor.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## S6-poison-gate-disabled

Class: substantive; exit 0; duration 51634 ms.

Command: `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 disabled`

Command SHA-256: `1f66dfd471dff584f83caa933efa8a124765776f6595a8221e8ad2110f397832`

Output SHA-256: `c1647155b29bb3911f261ea64aff41e163aa28971bd152dc10d2ebfaa16749d9`; [log](../evidence/S6-poison-gate-disabled.log); [receipt](../evidence/S6-poison-gate-disabled.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## S7-symlink-relative

Class: substantive; exit 0; duration 43895 ms.

Command: `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run relative`

Command SHA-256: `9a12b8bb02efcf5e5adbe1771e46dba198c33d1f64a10a246952e3d4ab246a00`

Output SHA-256: `5803fd16bb107ccb0f4a1c2640cbd4e613e096320409544ac55195fa8e1b5066`; [log](../evidence/S7-symlink-relative.log); [receipt](../evidence/S7-symlink-relative.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.

## S8-base-rebuild

Class: substantive; exit 0; duration 22887 ms.

Command: `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v6 base`

Command SHA-256: `52f3266f11643f1286c883a9ea6a43d54bac4ba28231c26121dee853a26d4e51`

Output SHA-256: `3ced274c03b74e67494c0a377e6f92e082ce2948ace4981d674e440cf7cbe5f3`; [log](../evidence/S8-base-rebuild.log); [receipt](../evidence/S8-base-rebuild.receipt).

Completed; attribution and scope are in the integrated row and guard ledger.
