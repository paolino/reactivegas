// Final document/hash packaging only. No subprocesses or audit executions.
const fs=require('fs'), path=require('path'), crypto=require('crypto');
const root=path.dirname(__dirname);
const read=p=>fs.readFileSync(path.join(root,p));
const write=(p,b)=>fs.writeFileSync(path.join(root,p),b);
const hash=p=>crypto.createHash('sha256').update(read(p)).digest('hex');
const files=[], links=[];
function walk(d){for(const n of fs.readdirSync(path.join(root,d)).sort()){const p=d+'/'+n,s=fs.lstatSync(path.join(root,p));if(s.isSymbolicLink())links.push({path:p,target:fs.readlinkSync(path.join(root,p))});else if(s.isDirectory())walk(p);else if(s.isFile())files.push(p);}}
walk('instruments');
const old='handoffs/INSTRUMENTS-pre-closeout.sha256';
if(!fs.existsSync(path.join(root,old)))fs.copyFileSync(path.join(root,'handoffs/INSTRUMENTS.sha256'),path.join(root,old));
const manifest=ps=>ps.sort().map(p=>hash(p)+'  '+p+'\n').join('');
write('handoffs/INSTRUMENTS.sha256',manifest(files));
write('handoffs/INSTRUMENT-SYMLINKS.json',JSON.stringify(links,null,2)+'\n');
const ev=fs.readdirSync(path.join(root,'evidence')).filter(n=>fs.lstatSync(path.join(root,'evidence',n)).isFile()).map(n=>'evidence/'+n);
write('handoffs/EVIDENCE.sha256',manifest(ev));
const auth=fs.readdirSync(root).filter(n=>n.endsWith('.md')&&n!=='STATUS.md');
for(const d of ['admitted','answers','questions'])for(const n of fs.readdirSync(path.join(root,d)))if(fs.lstatSync(path.join(root,d,n)).isFile())auth.push(d+'/'+n);
write('handoffs/AUTHORITY.sha256',manifest(auth));
write('handoffs/STATUS-PRE-HANDOFF.log',read('STATUS.md'));
const reportHash=hash('handoffs/AUDIT-REPORT.md');
const doc=`# Final local hash handoff

Verdict: **AUDIT-FINDINGS**. Candidate: \`714cb2a8536b24bf735295137e8f907782228380\`.

Report: [AUDIT-REPORT.md](AUDIT-REPORT.md), SHA-256 \`${reportHash}\`.

25 integrated rows: 24 CLOSED, 1 PARTLY. Element 1 retains one OPEN advisory documentation finding: missing REACTIVEGAS_ROOT defaults to cwd despite the header's fail-closed claim. No blocking functional defect demonstrated in the commissioned current-configuration behavior. NOTE-004 containment is a stated physical-layout assumption, not a present defect. NOTE-005 comparator/assertion limits are closed by P27/P28, with P29 the final complete scan. Untested auxiliary guard branches remain explicitly OPEN; no universal coverage claim.

Deliverables:

- [ROW-LEDGER.md](ROW-LEDGER.md) and [ROW-LEDGER.json](ROW-LEDGER.json): integrated decisions, commands, observations and guard limits.
- [EXECUTION-LEDGER.md](EXECUTION-LEDGER.md) and [EXECUTION-LEDGER.json](EXECUTION-LEDGER.json): all 38 preserved command/exit/hash receipts, including charged failures.
- [INSTRUMENTS.sha256](INSTRUMENTS.sha256): ${files.length} regular instrument/fixture files, refreshed through P29. The earlier manifest is retained as INSTRUMENTS-pre-closeout.sha256.
- [INSTRUMENT-SYMLINKS.json](INSTRUMENT-SYMLINKS.json): ${links.length} symbolic-link path/target records; symlink targets are not recursively hashed by this instrument manifest.
- [EVIDENCE.sha256](EVIDENCE.sha256): ${ev.length} retained evidence files, including every individual P27–P29 receipt/log.
- [AUTHORITY.sha256](AUTHORITY.sha256): ${auth.length} frozen/current authority and Q/A files. Superseded documents remain historical, not simultaneously operative.
- [STATUS-PRE-HANDOFF.log](STATUS-PRE-HANDOFF.log): immutable journal snapshot before terminal events; live STATUS.md stays append-only.
- [FINAL.sha256](FINAL.sha256): hashes of final documents, reporting scripts, snapshot and component manifests; excludes itself. Its hash is recorded in the terminal STATUS event.

Manifest paths are relative to the runtime root:
\`/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex\`.
For document/package verification only, use \`sha256sum -c handoffs/FINAL.sha256\` from that root; component manifests bind their listed files. This does not execute or revalidate any candidate control. These commands are instructions for reviewing the package, not an added campaign.

Release acknowledged: NOTE-006 / RELEASE-STORIES-20260905. Same seat/context; no fresh START, cap refund or new execution. Spend **9/9 substantive; 29/30 targeted**, unchanged. The unused targeted slot remains unused. Original receipt snapshots predating P27–P29 are retained unchanged; the final execution ledger uses individual receipts.

Candidate, worktree, caches, fixtures, failed attempts and pane preserved. No new build/probe, candidate edit, outward message, publication, push, PR action, merge or cleanup. This handoff completes the auditor's report obligation; acceptance and any follow-up authorization belong to the commissioning owner. No further work is queued by this seat.
`;
write('handoffs/HASH-HANDOFF.md',doc);
const finalFiles=fs.readdirSync(path.join(root,'handoffs')).filter(n=>n!=='FINAL.sha256'&&n!=='PACKAGE-CHECK.json').map(n=>'handoffs/'+n);
write('handoffs/FINAL.sha256',manifest(finalFiles));
// Verify only the newly produced package and its links, never rerun prior controls.
const mismatches=[];
for(const m of ['handoffs/FINAL.sha256','handoffs/INSTRUMENTS.sha256','handoffs/EVIDENCE.sha256','handoffs/AUTHORITY.sha256'])for(const line of read(m).toString().trimEnd().split('\n')){if(!line)continue;const want=line.slice(0,64),p=line.slice(66);if(hash(p)!==want)mismatches.push(p);}
const missingLinks=[];
for(const p of ['handoffs/AUDIT-REPORT.md','handoffs/ROW-LEDGER.md','handoffs/EXECUTION-LEDGER.md','handoffs/HASH-HANDOFF.md'])for(const m of read(p).toString().matchAll(/\]\(([^)]+)\)/g)){const dest=m[1];if(!dest.includes('://')&&!fs.existsSync(path.resolve(root,path.dirname(p),dest)))missingLinks.push([p,dest]);}
if(mismatches.length||missingLinks.length)throw Error(JSON.stringify({mismatches,missingLinks}));
console.log(JSON.stringify({report_sha256:reportHash,final_sha256:hash('handoffs/FINAL.sha256'),component_counts:{instruments:files.length,evidence:ev.length,authority:auth.length,final:finalFiles.length},package_hashes:'MATCH',document_links:'ALL_PRESENT',substantive:9,targeted:29}));
