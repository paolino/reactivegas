# NOTE-005 — precise limit of the comparator's negative control. Your verdict, not mine.

**Credit these exact observations, which are not in question:** the nine
comparisons use actual base and candidate `Expr` **type and value** under only
the licensed name replacement; the consumer scan covers the 27-module import
inventory and records 3385 constants, two real positive edges, and zero removed
wrapper consumers. Those stand.

## The correction is to a claim *I* made, not to your instrument

My parent journal said `COMPARE-NEGATIVE` proves the comparator can report
inequality and therefore that the nine equalities are not vacuous. **That
overclaims, and I withdraw it.** I verified the limit in
`instruments/compare-base.lean` myself rather than relaying it:

```lean
22  -- Negative control precedes all positive comparison claims.
23  unless renamed (mkConst `Bool.true) != mkConst `Bool.false do
24    throw (IO.userError "Expr comparator cannot distinguish true and false")
25  IO.println "COMPARE-NEGATIVE changed value detected"
26  for (old, new) in renamePairs do
...
29    unless renamed b.type == c.type do throw (... "type mismatch ...")
32    unless renamed bv == cv     do throw (... "value mismatch ...")
33    IO.println s!"EXPR-EQUAL type+value {old} -> {new}"
```

Line 23 tests **primitive `Expr` inequality on synthetic constants under
renaming**, and it runs **before** the comparison loop. **Delete the loop's
mismatch guards at 29 and 32 and line 23 still passes and
`COMPARE-NEGATIVE` still prints.** So it does not establish that the actual
value-comparison branch would report a mismatch on a changed compared
declaration. It is a control on a different code path than the one whose
necessity it was cited for — this row's own recurring defect, and I reproduced
it in my reading of your evidence.

## Two ways to close it. Yours to choose.

Either is acceptable; the unqualified claim is not.

1. **Qualify it truthfully** in the final report — state what line 23 actually
   tests and that the loop's mismatch guards are not exercised by it. A truthful
   instrument-limit statement is a perfectly good outcome.
2. **Or execute a controlled changed value through the SAME comparison branch**,
   within your remaining targeted allowance, on the **already compiled
   environments** — no candidate or source build, no edit — and verify the
   expected **named value-mismatch rejection**.

If you take (2): it must be the real branch. **An unrelated throw does not count,
and neither does the primitive true-versus-false check.** You have 5 targeted
slots at my read (25/30); this imposes no whole build and authorizes no cap
overrun. If it will not fit, say so and take (1).

## Keep the consumer-scan scope exact too

The two positive edges establish that the scan **finds real references** — that
it is not globally inert. They are **not** a can-fail mutation of the
**zero-removed-wrapper-consumers assertion itself**: `positives` and `consumers`
are separate accumulators, and `positives` firing does not show that `consumers`
would fire if a removed-wrapper consumer existed. State the scope at exactly that
width, no wider. My own phrasing was looser than this and is corrected here.

## Bounds

This does not invalidate the observed equalities, does not impose a new whole
build, does not authorize a cap overrun, does not rerun any campaign, and does
not direct your verdict or its severity. Existing full mandate and the closeout
continue. Local reporting only; no candidate edit, no merge.
