import Reactivegas.Step

/-!
# The law predicates

One predicate per documented law (issue #45); the prose record in
`docs/design/state-machine.md` references these names. The issue #48
economic amendment adds the comune-membership law, the stall, and the
group-closure guard facts.

Membership is read from the canonical `GroupView`. There is no
payload-local member or admin copy.
-/

/-- **Comune is not a member** (issue #48): the reserved comune account
lives inside `conti` at `comuneId` and is never a member of the
canonical view. Direct admission refuses it by identity. -/
def comune_not_a_member (view : KelGroups.GroupView) : Prop :=
  ¬ KelGroups.GroupView.isMember comuneId view

/-- **L6 Conservation**: `Σ casse − Σ conti − Σ open escrow = 0`. -/
def conservation (s : State) : Prop :=
  sumBal s.casse - sumBal s.conti - escrowSum s.collections = 0

/-- **L7 Solvency**: no member account ever goes below zero, and every
pledged amount stays non-negative so refunds can never push anyone
under. The first conjunct is restricted to actual members of the
canonical view. The reserved comune conto may legitimately go negative
(the stall) without making the group insolvent. -/
def solvent (view : KelGroups.GroupView) (s : State) : Prop :=
  (∀ u, KelGroups.GroupView.isMember u view → bal s.conti u ≥ 0) ∧
  (∀ col ∈ s.collections, ∀ p ∈ col.accepted ++ col.pending, 0 ≤ p.amount)

/-- A negative credit balance of a current member. -/
def insolvent (view : KelGroups.GroupView) (s : State) : Prop :=
  ∃ u, KelGroups.GroupView.isMember u view ∧ bal s.conti u < 0

/-- **L8 Pledge uniqueness**, one collection at a time:
one pledge per user per collection. -/
def uniquePledges (col : Collection) : Prop :=
  ∀ p ∈ col.accepted ++ col.pending,
    ∀ q ∈ col.accepted ++ col.pending, p.user = q.user → p = q

/-- L8 lifted to the whole state. -/
def allUniquePledges (s : State) : Prop :=
  ∀ col ∈ s.collections, uniquePledges col

/-- **L2 Closure permission**: positive closure requires the group's
assent (`permitted`) *and* zero pending pledges. -/
def permissionToClose (col : Collection) : Prop :=
  col.permitted ∧ col.pending = []

/-- **L3 Escrow at pledge**: user `u` currently has `v` held in the
pending pledges of `col`. -/
def escrowHeld (col : Collection) (u : KelGroups.Key) (v : Int) : Prop :=
  ∃ pend, splitUser u col.pending = some (v, pend)

/-- **L1 Governance enacts**: after enacting the removal of `u`, no open
question (collection) is left with `u` as referente. Discharged by the
sealed base hook — `windUpAdmin` cancels them — and witnessed by
`Reactivegas.checkAdminDepartureCleanup`. -/
def governanceEnacts (u : KelGroups.Key) (s' : State) : Prop :=
  ∀ c ∈ s'.collections, c.referente ≠ u

/-- **L5 Double entry**: a deposit or withdrawal of `v` moves user `u`'s
conto and cashier `a`'s cassa together. -/
def doubleEntry (s s' : State) (a u : KelGroups.Key) (v : Int) : Prop :=
  bal s'.conti u = bal s.conti u + v ∧ bal s'.casse a = bal s.casse a + v

/-- **AUTH**: every declaration is signed by a current responsabile of
the canonical view. Exhaustive over the fourteen-constructor `Event`
vocabulary, which no longer contains a membership or role constructor
to name an author for. -/
def authorizedStep (view : KelGroups.GroupView) (_s : State) (e : Event)
    (_s' : State) : Prop :=
  match e with
  | .openPurchase a _ | .grantPermission a _
  | .denyPermission a _ | .donate a _ | .backdonate a _
  | .deposit a _ _ | .withdraw a _ _ | .transferCassa a _ _
  | .pledge a _ _ _ | .acceptPledge a _ _ | .refusePledge a _ _
  | .correctPledge a _ _ _ | .closePurchase a _ | .failPurchase a _ =>
    isResponsabile view a

/-- **Group closure — ruled guard facts only** (issue #48). -/
def canCloseGroup (view : KelGroups.GroupView) (s : State) : Prop :=
  (∀ u, KelGroups.GroupView.isMember u view → bal s.conti u = 0) ∧
  s.collections = [] ∧
  (∀ r : KelGroups.Key, bal s.casse r = 0)

/-- Reachability from the empty economic payload through successful
integrated app steps under a fixed canonical view. `stepEvent` is the
app-payload surface and cannot change the view; base transitions and
their sealed cleanup are observed through `Reactivegas.apply` instead.
The boot case requires the
reserved `comuneId` not to be a member of that view. -/
inductive Reach (view : KelGroups.GroupView) (auth : BackdonateAuth) :
    State → Prop where
  | boot (h : comune_not_a_member view) : Reach view auth State.empty
  | trans {s : State} {e : Event} {s' : State} :
    Reach view auth s → stepEvent view s e auth = some s' →
      Reach view auth s'
