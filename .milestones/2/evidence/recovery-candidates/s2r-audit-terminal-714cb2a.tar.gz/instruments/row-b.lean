import Lean
import KelGroups
import KelGroups.Event
import KelGroups.Fold
import KelGroups.Integration
import KelGroups.Invariants
import KelGroups.State
import KelGroups.Tests
import KelGroups.Types
import KelGroups.Validate
import KelGroups.Vote.Event
import KelGroups.Vote.Fold
import KelGroups.Vote.Invariants
import KelGroups.Vote.State
import KelGroups.Vote.Tests
import KelGroups.Vote.Types
import KelGroups.Vote.Validate
import Reactivegas
import Reactivegas.Composition
import Reactivegas.CorpusExport
import Reactivegas.CorpusGate
import Reactivegas.Invariants
import Reactivegas.Predicates
import Reactivegas.State
import Reactivegas.Step
import Reactivegas.Trace
import Reactivegas.TraceTests
import Reactivegas.Types

open Lean Meta Elab Term
#eval show TermElabM Unit from do
  let env ← getEnv
  for n in [`Reactivegas.i57TrustNoSorry, `Reactivegas.kelGroupsHasNoReactivegasImport, `Reactivegas.leanToolchainMatchesPin, `Reactivegas.checkI57Trust, `Reactivegas.checkI57Direction, `Reactivegas.checkI57Toolchain, `Reactivegas.i57_trust_holds, `Reactivegas.i57_direction_holds, `Reactivegas.i57_toolchain_holds, `TraceTests.checkI57Trust, `TraceTests.checkI57Direction, `TraceTests.checkI57Toolchain] do
    if (env.find? n).isSome then throwError "unexpected old name {n}"
    IO.println s!"absent-ok {n}"
  for n in [`Reactivegas.admissionPreservationReachable, `Reactivegas.productionWellFormedAndComuneExcluded, `Reactivegas.comuneIdentityAndThresholdSanity, `Reactivegas.checkAdmissionPreservation, `Reactivegas.checkProductionWellFormed, `Reactivegas.checkComuneThresholdSanity, `Reactivegas.admissionPreservation_holds, `Reactivegas.productionWellFormed_holds, `Reactivegas.comuneThresholdSanity_holds] do
    if (env.find? n).isNone then throwError "missing new name {n}"
    IO.println s!"present-ok {n}"
#eval Reactivegas.checkAdmissionPreservation
#eval Reactivegas.checkProductionWellFormed
#eval Reactivegas.checkComuneThresholdSanity

