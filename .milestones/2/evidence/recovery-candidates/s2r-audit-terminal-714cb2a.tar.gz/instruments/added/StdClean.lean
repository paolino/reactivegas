import Std.Data.DHashMap

namespace AuditOutside
theorem validExtension : True := True.intro
end AuditOutside
