import Reactivegas.Invariants

#eval Reactivegas.checkIntegratedCorpus

axiom auditForbidden : False
def auditBridge : False := auditForbidden
theorem auditDirect : False := auditForbidden
theorem auditTransitive : False := auditBridge
