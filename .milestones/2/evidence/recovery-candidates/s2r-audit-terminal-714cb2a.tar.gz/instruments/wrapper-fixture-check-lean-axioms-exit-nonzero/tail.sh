#!/usr/bin/env bash
set -euo pipefail
tmp="/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/wrapper-fixture-check-lean-axioms-exit-nonzero"
TOOL=check-lean-axioms
code=7
cat "$tmp/axioms.out" 2>/dev/null || true
cat "$tmp/axioms.err" >&2 2>/dev/null || true
if grep -q 'PANIC at' "$tmp/axioms.out" "$tmp/axioms.err" 2>/dev/null; then
    printf '%s: gate output contains a panic string\n' "$TOOL" >&2
    exit 1
fi
if [ $code -ne 0 ]; then exit $code; fi
if ! grep -q '^axiom-gate: ok' "$tmp/axioms.out" 2>/dev/null; then
    printf '%s: missing axiom-gate: ok marker\n' "$TOOL" >&2
    exit 1
fi
