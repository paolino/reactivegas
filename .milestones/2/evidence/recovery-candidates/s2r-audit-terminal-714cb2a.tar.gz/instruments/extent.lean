import Lean
import KelGroups
import KelGroups.Event
import KelGroups.Fold
import KelGroups.Integration
import KelGroups.Invariants
import KelGroups.State
import KelGroups.Tests
import KelGroups.Types
import KelGroups.Validate
import KelGroups.Vote.Event
import KelGroups.Vote.Fold
import KelGroups.Vote.Invariants
import KelGroups.Vote.State
import KelGroups.Vote.Tests
import KelGroups.Vote.Types
import KelGroups.Vote.Validate
import Reactivegas
import Reactivegas.Composition
import Reactivegas.CorpusExport
import Reactivegas.CorpusGate
import Reactivegas.Invariants
import Reactivegas.Predicates
import Reactivegas.State
import Reactivegas.Step
import Reactivegas.Trace
import Reactivegas.TraceTests
import Reactivegas.Types
import Std.Data.DHashMap

open Lean Meta Elab Term
#eval show TermElabM Unit from do
  let env ← getEnv
  let sp ← Lean.searchPathRef.get
  let root ← IO.FS.realPath "/code/reactivegas-66-s2r-audit"
  let mut owned : Array Name := #[]
  for m in env.header.moduleNames do
    let some p ← sp.findModuleWithExt "olean" m | throwError "missing artifact {m}"
    let real ← IO.FS.realPath p
    let project := (root.toString ++ "/").isPrefixOf real.toString
    IO.println s!"RESOLVED {m} project={project} path={real}"
    if project then owned := owned.push m
  let mut count := 0
  for (n, ci) in env.constants.toList do
    if let .thmInfo _ := ci then
      if let some idx := env.getModuleIdxFor? n then
        if let some m := env.header.moduleNames[idx.toNat]? then
          if owned.contains m then
            count := count + 1
            IO.println s!"THEOREM {m} {n}"
  IO.println s!"EXTENT owned={owned.size} theorems={count}"
