export AUDIT_LEAN=/nix/store/4gr3n4nrp0xxgykyyzdxi3xjj2ikn5x1-lean4-4.25.0/bin/lean
export AUDIT_LEAN_PATH=/code/reactivegas-66-s2r-audit/lean/.lake/build/lib/lean:/nix/store/4gr3n4nrp0xxgykyyzdxi3xjj2ikn5x1-lean4-4.25.0/lib/lean
