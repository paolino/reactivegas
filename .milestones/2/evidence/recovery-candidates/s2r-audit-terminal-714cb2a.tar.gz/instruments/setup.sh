#!/usr/bin/env bash
set -euo pipefail
r=/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex
cd /code/reactivegas-66-s2r-audit/lean
lp=$(lake env printenv LEAN_PATH)
lbin=$(command -v lean)
printf 'export AUDIT_LEAN=%q\nexport AUDIT_LEAN_PATH=%q\n' "$lbin" "$lp" > "$r/instruments/env.sh"
printf 'LEAN=%s\nLEAN_PATH=%s\n' "$lbin" "$lp"
lean --version
