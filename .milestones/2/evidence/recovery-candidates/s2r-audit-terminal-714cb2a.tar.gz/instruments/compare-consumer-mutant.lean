import Lean
open Lean

def renamePairs : List (Name × Name) := [(`Reactivegas.i57TrustNoSorry, `Reactivegas.admissionPreservationReachable), (`Reactivegas.kelGroupsHasNoReactivegasImport, `Reactivegas.productionWellFormedAndComuneExcluded), (`Reactivegas.leanToolchainMatchesPin, `Reactivegas.comuneIdentityAndThresholdSanity), (`Reactivegas.checkI57Trust, `Reactivegas.checkAdmissionPreservation), (`Reactivegas.checkI57Direction, `Reactivegas.checkProductionWellFormed), (`Reactivegas.checkI57Toolchain, `Reactivegas.checkComuneThresholdSanity), (`Reactivegas.i57_trust_holds, `Reactivegas.admissionPreservation_holds), (`Reactivegas.i57_direction_holds, `Reactivegas.productionWellFormed_holds), (`Reactivegas.i57_toolchain_holds, `Reactivegas.comuneThresholdSanity_holds)]
def renamed (e : Expr) : Expr := e.replace fun x => match x with
  | .const n us => match renamePairs.find? (fun p => p.1 == n) with
    | some p => some (.const p.2 us)
    | none => none
  | _ => none

def main : IO Unit := do
  let imports : Array Import := #[{module := `KelGroups}, {module := `KelGroups.Event}, {module := `KelGroups.Fold}, {module := `KelGroups.Integration}, {module := `KelGroups.Invariants}, {module := `KelGroups.State}, {module := `KelGroups.Tests}, {module := `KelGroups.Types}, {module := `KelGroups.Validate}, {module := `KelGroups.Vote.Event}, {module := `KelGroups.Vote.Fold}, {module := `KelGroups.Vote.Invariants}, {module := `KelGroups.Vote.State}, {module := `KelGroups.Vote.Tests}, {module := `KelGroups.Vote.Types}, {module := `KelGroups.Vote.Validate}, {module := `Reactivegas}, {module := `Reactivegas.Composition}, {module := `Reactivegas.CorpusExport}, {module := `Reactivegas.CorpusGate}, {module := `Reactivegas.Invariants}, {module := `Reactivegas.Predicates}, {module := `Reactivegas.State}, {module := `Reactivegas.Step}, {module := `Reactivegas.Trace}, {module := `Reactivegas.TraceTests}, {module := `Reactivegas.Types}]
  let original ← searchPathRef.get
  let basePath := "/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/../cache-base/build/lib/lean"
  let currentPath := "/code/reactivegas-66-s2r-audit/lean/.lake/build/lib/lean"
  let toolPath := "/nix/store/4gr3n4nrp0xxgykyyzdxi3xjj2ikn5x1-lean4-4.25.0/lib/lean"
  searchPathRef.set [basePath, toolPath]
  let base ← importModules imports {}
  searchPathRef.set [currentPath, toolPath]
  let candidate ← importModules imports {}
  searchPathRef.set original
  -- Negative control precedes all positive comparison claims.
  unless renamed (mkConst `Bool.true) != mkConst `Bool.false do
    throw (IO.userError "Expr comparator cannot distinguish true and false")
  IO.println "COMPARE-NEGATIVE changed value detected"
  for (old, new) in renamePairs do
    let some b := base.find? old | throw (IO.userError s!"missing base {old}")
    let some c := candidate.find? new | throw (IO.userError s!"missing candidate {new}")
    unless renamed b.type == c.type do throw (IO.userError s!"type mismatch {old} -> {new}")
    let some bv := b.value? | throw (IO.userError s!"base no value {old}")
    let some cv := c.value? | throw (IO.userError s!"candidate no value {new}")
    unless renamed bv == cv do throw (IO.userError s!"value mismatch {old} -> {new}")
    IO.println s!"EXPR-EQUAL type+value {old} -> {new}"
  let targets := [`TraceTests.checkI57Trust, `TraceTests.checkI57Direction, `TraceTests.checkI57Toolchain]
  for t in targets do
    if (base.find? t).isNone then throw (IO.userError s!"scan absent target {t}")
    if (candidate.find? t).isSome then throw (IO.userError s!"candidate retained target {t}")
    IO.println s!"TARGET-BASE-PRESENT-CANDIDATE-ABSENT {t}"
  let modules := imports.map (·.module)
  let mut scanned := 0
  let mut positives := 0
  let mut consumers := 0
  for (n, ci) in base.constants.toList do
    let some idx := base.getModuleIdxFor? n | continue
    let some m := base.header.moduleNames[idx.toNat]? | continue
    if !modules.contains m then continue
    scanned := scanned + 1
    let usedValue := if n == `TraceTests.checkI57Direction then some (mkConst `TraceTests.checkI57Trust) else ci.value?
    let refs := ci.type.getUsedConstants ++ (usedValue.map (·.getUsedConstants)).getD #[]
    if refs.contains `Reactivegas.checkI57Trust then
      positives := positives + 1
      IO.println s!"CONSUMER-POSITIVE {n} -> Reactivegas.checkI57Trust"
    for target in targets do
      if refs.contains target then
        consumers := consumers + 1
        IO.println s!"WRAPPER-CONSUMER {n} -> {target}"
  unless positives > 0 do throw (IO.userError "consumer scan positive control empty")
  IO.println s!"BASE-CONSUMER-SCAN modules={modules.size} constants={scanned} positive={positives} removed-wrapper-consumers={consumers}"
  unless consumers == 0 do throw (IO.userError "removed wrappers have base consumers")
#eval main
