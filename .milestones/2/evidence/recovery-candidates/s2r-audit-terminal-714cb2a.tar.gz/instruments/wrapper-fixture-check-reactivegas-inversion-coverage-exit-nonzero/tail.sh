#!/usr/bin/env bash
set -euo pipefail
tmp="/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/wrapper-fixture-check-reactivegas-inversion-coverage-exit-nonzero"
TOOL=check-reactivegas-inversion-coverage
code=7
cat "$tmp/audit.out" 2>/dev/null || true
cat "$tmp/audit.err" >&2 2>/dev/null || true
if grep -q 'PANIC at' "$tmp/audit.out" "$tmp/audit.err" 2>/dev/null; then
    printf '%s: gate output contains a panic string\n' "$TOOL" >&2
    exit 1
fi
if [ $code -ne 0 ]; then exit $code; fi
if ! grep -q '^inversion-audit: ok' "$tmp/audit.out" 2>/dev/null; then
    printf '%s: missing inversion-audit: ok marker\n' "$TOOL" >&2
    exit 1
fi
