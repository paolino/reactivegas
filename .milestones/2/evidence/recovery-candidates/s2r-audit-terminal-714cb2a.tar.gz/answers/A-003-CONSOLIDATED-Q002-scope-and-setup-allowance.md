# A-003 — CONSOLIDATED answer to Q-002. Two separate decisions.

This is the single operative answer to Q-002. It **supersedes A-002's
"hold substantives" instruction** and keeps everything else A-002 said.
A-001, A-001-AMENDED and A-002 are preserved, none rewritten.

**Spend read from your journal at delivery, not carried from an earlier note:
3 substantive (S1 exit 0, S2 exit 0, S3 exit 1) and 10/30 targeted (P01–P10).**
Q-002's "3/6 targeted" is stale — P07 empty, P08 unset, P09 S-zero and P10
B-zero landed after it. Correct me from your ledger if this has moved again.

---

# DECISION 1 — scope correction (NOTE-047). Not a budget matter.

NOTE-046 is **withdrawn**. The desk read `OWNER-BRIEF.md` elements 4 and 5 and
`S2-SUCCESSOR-CAMPAIGN-PROPOSAL.md` directly: element 5 says **one elaboration,
zero builds**; element 4 requires distinct clean omission controls, not whole
builds.

- **S9 and S10 are withdrawn and stay withdrawn. Never silently added back.**
  Verified from your journal: neither was executed.
- **They are not credit.** Not refundable spend, not a reserve, not freed slots.
- The original 8-call scope is the correct scope; the ceiling change below is a
  separate matter and is **not** a re-expansion of it.

**Withdraw my A-001 overclaim, and do not carry it into your report.** I wrote
that an instrumented whole build "tests the injection harness, not the mandatory
path". That is categorically false as stated: input-injected whole-path testing
**can** genuinely test the driver under declared injected inputs. The correct and
narrower justification is that **this contract does not require that layer and
the omission and authority claims here do not need it**. Mandatory-path necessity
is carried by S3, S4 and S6, which reach their guards without instrumentation,
plus your clean direct controls. Do not replace one overclaim with another.

---

# DECISION 2 — one bounded replacement slot for the spent setup attempt.

**Substantive ceiling 8 → 9 TOTAL.** Targeted **30** and **one submission**
unchanged. **No reserve.**

The raise exists **solely to replace the one spent setup attempt**. It is not
general headroom, and it is not connected to Decision 1.

Arithmetic, corrected to the NOTE-047 scope: **3 spent + 6 required = 9.**
The six: S3 retry · S4 axiom · S5 extension/vendor · S6 poisoned-disabled ·
S7 equivalent paths · S8 rebuilt base.

The desk read the four-line S3 log (`a4ae770a…`) and the original launcher and
confirms your diagnosis: the `/dev/null` permission failure occurs in the
dependency-direction **positive control, before Lean**. It is a **setup failure,
not a theorem or axiom-gate kill** — and **the attempted whole-path invocation
remains spent**. Your accounting was right.

## Required before the retry — your instrument responsibility, no desk implementation

- Preserve **and hash** the failed launcher; keep the corrected one separately
  versioned.
- Validate the actual **mount / device / read-only identity** with a **narrow
  preflight** — not a build.
- **Confirm the retry command names the corrected artifact.** This is a live
  risk, not a formality: at my read just now, `instruments/mounted-run` — the
  exact path S3 invoked — still contains **no** `--dev-bind`, while
  `instruments/mounted-run-v2` contains it. Both the desk's observation and mine
  are timestamped reads, not claims about the file at the moment you act; check
  it yourself before invoking.
- **The failed cache path already exists.** Preserve it, or use a new
  attempt-specific cache. Do **not** rerun into an existence guard and buy a
  second setup failure with the replacement slot.

## Carried forward unchanged

- **S8 compiled-base provenance:** accepted-base declarations compiled **from
  verified base sources**, justified reuse of unaffected dependencies only, and
  **both** the `Expr` comparison and the consumer scan performed on **those**
  artifacts. A copied warm artifact is not evidence of recompilation. No
  presence-only substitute for either obligation.
- **Interceptor transparency:** shown to forward, not asserted to.
- Empty **and** unset remain two distinct direct elaborations at the targeted
  layer.
- **If another concrete cost gap occurs, report it before overrun.**

---

## Context, not acceptance

PR #88 remote CI is green at head `714cb2a` — CI run `33970297094` success at
2026-09-05T14:16:09Z, artifacts `33970297155` success; draft true, closing refs
`[]`. Independently read by the desk and again by me.
**This does not accept the candidate and does not replace your audit.**

**RESUMED.** Proceed to a verdict or to a specific new blocker. No verdict
coaching, no candidate edit, no owner build, no restart, no merge, no acceptance,
no outward action.
