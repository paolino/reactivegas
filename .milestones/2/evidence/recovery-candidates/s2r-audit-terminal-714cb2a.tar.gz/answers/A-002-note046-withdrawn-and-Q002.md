# A-002 — NOTE-046 withdrawn; back to 8/30. And your Q-002 arithmetic is now exactly right.

This supersedes `A-001-AMENDED-desk-ruling.md`. `A-001-invocation-layer-reconciliation.md`
is reinstated on the layer question. All three are preserved; none is rewritten.

## S9 and S10 are withdrawn again, and the raise with them

The desk read `OWNER-BRIEF.md` elements 4 and 5 and
`S2-SUCCESSOR-CAMPAIGN-PROPOSAL.md` directly and found the contract reading
correct: element 5 says **one elaboration, zero builds**; element 4 requires
distinct clean omission controls, not whole builds. NOTE-046 converted your
conditional cost proposal into a required path without first checking that
authority.

- **Substantive ceiling returns to 8. Targeted stays 30.**
- **S9 and S10: do not run them.** I verified from your journal that neither was
  executed — no `id=S9`, no `id=S10`. Nothing is lost and nothing is wasted.
- **The withdrawn calls are NOT credit.** Not refundable spend, not a reserve,
  not two freed slots. Eight named uses again.

You were sent a restore and then a withdrawal within minutes. That churn is on
the routing above you, not on you, and none of it consumed your budget.

## A correction to my own reasoning — do not carry my overclaim forward

A-001 said an instrumented whole build "tests the injection harness, not the
mandatory path". **That is an overclaim and I withdraw it.** Input-injected
whole-path testing is **not categorically** a harness test; it can genuinely test
the driver under declared injected inputs.

The correct, narrower justification — use this one: **that layer is not required
by this contract and is not necessary for the omission or authority claims
here.** Mandatory-path necessity is carried by S3, S4 and S6, which reach their
guards without instrumentation, plus the clean direct controls you have already
run. Do not replace one overclaim with another in your report.

## Still binding, unchanged

- **S8's compiled-base provenance condition** survives NOTE-046's withdrawal in
  full: accepted-base declarations compiled **from verified base sources**,
  justified reuse of unaffected dependencies only, and **both** the `Expr`
  comparison and the consumer scan performed **on those artifacts**. A copied
  warm artifact is not evidence that the Row B declarations were recompiled. No
  presence-only substitute for either obligation.
- **Interceptor transparency**, exactly as in A-001: shown to forward, not
  asserted to.
- Empty **and** unset remain two distinct direct elaborations at the targeted
  layer.

## Q-002 — your arithmetic was right, and it is now the operative arithmetic

Q-002 was filed against the cap of 8. That cap is restored, so it stands exactly
as you wrote it. **Nine required against a cap of eight: a concrete gap of one
substantive invocation.** Spend read from your journal at this writing: **3/8
substantive, 10/30 targeted**.

Your handling of the S3 failure is correct on every point and I am not asking you
to redo any of it: you named it as your own setup error rather than a semantic
result, preserved the failed launcher as `mounted-run-v1-failed`, versioned the
corrected one separately, took no automatic retry, and stated plainly that a
denial leaves the row OPEN with no PASS.

I verified the diagnosis independently rather than accepting it. `S3-sorry.log`
is four lines: `/dev/null: Permission denied` twice from
`nix/lean-dependency-direction.sh`, then `dependency scanner could not find a
known Reactivegas import`, then the recipe failing. The dependency-direction
script fails its **known-import positive control** before any Lean build or gate
runs. That is a wrong-layer setup failure, not a kill — and per the standing rule
a wrong-layer failure never counts as a kill, while the **invocation still counts
as spent and is not refunded**. Your 3/8 is correct. I also confirmed your
worktree is clean at `714cb2a` with the mutation confined to the private mount.

**The gap is escalated to the desk.** I am not granting it: the ceiling is not
mine to raise, and NOTE-047 forbids treating the withdrawn S9/S10 as credit,
which is the one move that would make this arithmetic close without a ruling.

**Hold substantive invocations pending that disposition.** Continue targeted
controls within 30 and the free source and provenance review. If a further setup
failure or gap appears, report it the same way, before overrun.

No verdict coaching, candidate edit, owner build, restart, merge or acceptance.
