# A-001 AMENDED — the desk overruled my layer disposition. S9 and S10 are RESTORED.

Read this against `A-001-invocation-layer-reconciliation.md`, which it amends.
Where they conflict, **this governs**. The desk read Q-001 in full together with
your post-START amendment and receipts, and ruled.

## What is withdrawn

My "S9 withdrawn, S10 withdrawn. Do not run them" is **revoked**. That
instruction is void; do not act on it.

My reasoning was that an instrumented whole build tests the injection harness
rather than the mandatory path. The desk's answer is the condition it attached:
**the intended finding must be isolated**, and **instrumented evidence must be
labelled as instrumented**. An unrelated build, import or setup failure is not a
kill and cannot be credited to the row. With disclosure and finding-isolation
required, the masking objection is answered rather than ignored. I was overruled
on the merits and I am recording it that way.

Your layer analysis stands and is now binding in one respect the desk endorsed
explicitly: **merely setting an outer `LEAN_PATH` that Lake overwrites does not
exercise that input.** You identified that correctly.

## What is authorized

**Substantive ceiling 8 → 10 TOTAL**, targeted **30 unchanged**, no reserve, no
new submission. All executed receipts are preserved at their actual invocation
classes and **nothing is refunded**.

**Spend read at actual delivery rather than asserted:** **2/10 substantive**
(S1, S2 both exit 0) and **6/30 targeted** (P01–P06). Correct me from your own
ledger if that has moved by the time you read this — I am reading it, not
remembering it.

The concrete ten-call table, this authorization and NOTE-046 itself are written
into the admitted contract at
`admitted/POST-START-AUTHORIZATION-001-ten-call-table.md`
(`f7f0a33a5b7ab55950f0554311979b528627792ac84c5d952a5877be5bd1e85e`) with
`MANIFEST.sha256` refreshed. Read it; it carries the full table and every
condition.

## The conditions, so they are not lost in the table

- **S9** — genuine `just lean` reaching project-owned `B \ S` under the declared
  driver-input mutation. **Must isolate the intended finding.**
- **S10** — genuine `just lean` reaching missing-authority under the declared
  final-driver environment mutation, **unset** form. **Must isolate the intended
  finding.** One unset full-path execution suffices; there is no eleventh call.
- **This is not permission to omit a direct variant.** Empty **and** unset remain
  two required, distinct, direct elaborations at the targeted layer.
- **S5 / S7 combinations** only if each required input form actually reaches the
  intended production driver **and** has its own observed result inside the
  receipt. Label instrumented mandatory-path evidence as instrumented, preserving
  the actual candidate driver except for the one named input. Direct-driver
  checks stay distinct evidence, separately counted.
- **S8** — no warm-artifact substitute. A copied warm artifact is not evidence
  that the accepted-base Row B declarations were recompiled. Require actual base
  source and compiled provenance and an **observed rebuild of the affected
  modules** before consuming them; reuse only justified unaffected dependencies.
  No presence-only substitute for either obligation. Your
  `evidence/base-blob-equality.txt` already discharges the blob-equivalence check
  from the repository rather than from my read — that was the right instinct.
- **If a combined call cannot establish each row, or setup or extra calls would
  exceed ten, return the new concrete gap before overrun.** Do not spend past ten
  and do not silently omit a row.

## Noted, not coached

Your P02/P03 with P04/P05 are a properly unmasked necessity pair: `S \ B` exits 1
naming only `Reactivegas.TraceTests` and `B \ S` exits 1 naming only
`KelGroups.Tests`, while the same inputs with only the respective guard disabled
both reach `axiom-gate: ok` at exit 0. That is the evidence no owner receipt
could supply, and it is what the P26/P27 contamination limit was held open for.
Whether it discharges that limit is **your** determination in the verdict, not
mine — I am recording what the logs show, not telling you what to conclude.

No verdict coaching, no candidate edit, no owner build, no restart, no merge, no
acceptance, no outward action. **RESUME the full audit.**
