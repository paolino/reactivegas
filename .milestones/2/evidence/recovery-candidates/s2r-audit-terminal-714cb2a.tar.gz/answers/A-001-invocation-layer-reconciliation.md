# A-001 — layer bound. No gap, no raise, and no reclassification-to-fit.

Q-001 is the right escalation, made at the right time, with the gap quantified
before overrun. The reasoning is sound and the technical finding behind it —
that Lake reinstates `LEAN_PATH`, so an unmodified `just lean` cannot reach
G-001 — is correct and is now on the record.

**Both rows stay MANDATORY. Neither is dropped, weakened, or demoted to fit a
budget. The layer question is answered by the contract and by the masking rule,
and the answer would be the same if you had six free slots.**

## Element 5 / missing-authority — the contract already names the layer

This is not a judgement call. Two authority documents specify it in their own
words:

- `OWNER-BRIEF.md` (`be6e9416…`), element 5: "execute **that exact control**
  (instrument prepared and hashed; **one elaboration, zero builds**)".
- `S2-SUCCESSOR-CAMPAIGN-PROPOSAL.md` (`5ef67ef4…`), element 5: "**one targeted
  elaboration, zero builds**".

The missing-authority control is contractually a **targeted elaboration**. Row 5
of the auditor allocation was a budgeting artifact, not a requirement for a whole
build — and running it as one would contradict the contract's explicit "zero
builds". Empty and unset remain **two distinct direct elaborations**, as the
contract's instrument was prepared for.

**S10 is withdrawn. Do not run it.**

## Element 4 / `B \ S` — the whole-build variant cannot be an unmasked control

The contract (both documents, element 4) requires that `S \ B` and `B \ S` both
fire on genuinely project-owned subjects with the layers kept explicitly
distinct. It does **not** name an invocation layer.

The admitted packet establishes, and the desk accepted with the mapping note
intact, that `B \ S` through `just lean` is **unreachable by construction**: the
driver imports exactly S, so any file-level omission fires first at the bash
S-agreement or at the build. Reaching it through the mandatory path therefore
requires injecting a divergence at the final gate driver call — and an
instrumented whole build of that shape **tests the injection harness, not the
mandatory path**. That is precisely the masking rule this lane has already
applied twice: a control that exits non-zero for a reason other than the guard
under test proves nothing about that guard, and its dual, a control whose
non-zero exit is manufactured by the instrument.

The direct-driver probe on clean inputs is the layer where this control is
**unmasked**. That is where it runs.

**S9 is withdrawn. Do not run it.**

## Where the whole-build reachability claim actually goes

The legitimate claim those two slots were implicitly carrying — *the mandatory
path invokes the gate and honours its verdict* — is **explicitly reassigned** to
the rows that reach their guards **without instrumentation**:

- **S3** — `sorry` through `just lean`, rejected for its dependency.
- **S4** — forbidden axiom and consuming theorem through `just lean`, direct and
  transitive uses named.
- **S6** — same poison, axiom-gate call removed, expected GREEN.

S6 is the load-bearing one and your framing of it is right: poison present, gate
removed, green — that shows the gate did the killing. A clean tree without the
gate would be a baseline-green decoy and would show nothing.

Record this reassignment in your report as a **layer determination with its
reason**, so the record shows the rows were *placed*, not dropped. A reader must
be able to see which invocation establishes each of the two rows and why that is
the correct layer.

## Your interceptor for S5/S7 — permitted, with one condition

Input mutation that leaves the tracked tree immutable is legitimate, and for
element 3 the loader input *is* the subject, so mutating it is the control rather
than a distortion of it. Proceed.

**Condition, and it is this lane's own discipline turned on your instrument:** an
interceptor that claims to forward genuine whole builds unchanged must be
*shown* to forward, not asserted to. Preserve the interceptor and hash it, and
establish transparency from evidence you already hold — S1 and S2 ran without it,
so an intercepted-but-not-injecting run that reproduces S1's numbers exactly
would do it at zero additional substantive cost if it can ride an existing slot.
If transparency cannot be established without a further whole build, **say so as
a gap** rather than spending a slot on it or letting the assumption stand.

## Standing

Substantive stays **8**, targeted **30**. No raise is granted and none is needed:
your list is 8 named uses with S8 the mandatory `d670323` base rebuild and no
reserve, so a failed setup or repair is a gap you report, not a slot you spend.
Verify the three Row B blobs against `4a6cd87` yourself before S8, as you said
you would.

Resume the full audit. Nothing here changes the two settling obligations: both
omission controls on your own clean artifacts with no unrelated finding — `S \ B`
is already established at P02 with the sole `Reactivegas.TraceTests` finding —
and the decoy test applied to the new gate.
