# POST-START AUTHORIZATION 001 — substantive ceiling 8 → 10, concrete ten-call table

Source: desk NOTE-046 (`admitted/NOTE-046-quality-auditor-q001-layer-budget.md`),
issued after reading Q-001 in full together with the auditor's own post-START
amendment and receipts. Binding on this audit. It **overrules** the parent's
A-001 withdrawal of S9 and S10.

**Spend read at actual delivery, not asserted from an earlier observation:**
**2/10 substantive** (S1, S2) and **6/30 targeted** (P01–P06). Every executed
receipt is preserved at its actual invocation class. Nothing is refunded.

## Ceilings

- Substantive **8 → 10 TOTAL** for this one fresh full S2R audit.
- Targeted **30, unchanged**.
- **No reserve.** Ten named uses. No new submission.

## The ten calls

| # | call | establishes | state |
|---|---|---|---|
| S1 | cold `just lean`, `.lake` absent | A1 · A3 · census identities | **EXECUTED, exit 0** |
| S2 | full `just ci` | A7 · exporter integration | **EXECUTED, exit 0** |
| S3 | `just lean`, existing non-inversion theorem → `sorry` | A5 sorry · AMENDMENT-1 | pending |
| S4 | `just lean`, forbidden axiom + intermediary def + consuming theorem | A6, direct **and** transitive uses named | pending |
| S5 | `just lean`, registered outside-namespace module importing `Std`, plus vendor-first loader input | A5 added-module · F-001 · F-003 · element 2 alias/dependency | pending, **combination conditioned** |
| S6 | `just lean`, S3 poison retained, axiom-gate call removed | **necessity** — expect GREEN | pending |
| S7 | `just lean` through symlinked cwd with relative project entry at the actual `lake env lean` calls | element 1 · element 3 · F-004 | pending, **combination conditioned** |
| S8 | **base rebuild at `d670323`** | Row B compiled `Expr` equality **and** compiled base consumer scan | pending, **mandatory** |
| S9 | **genuine `just lean` reaching project-owned `B \ S`** under declared driver-input mutation | element 4 at the mandatory-path layer | pending, **restored** |
| S10 | **genuine `just lean` reaching missing-authority** under declared final-driver environment mutation, **unset** form | element 5 / G-001 at the mandatory-path layer | pending, **restored** |

## Conditions the desk attached, in force

**S9 and S10 must isolate the intended finding.** An unrelated build, import or
setup failure is **not a kill** and cannot be credited to the row.

**No eleventh call.** One **unset** full-path execution of the missing-authority
row suffices. This is **not** permission to omit either direct variant: **empty
and unset remain two required, distinct, direct elaborations** at the targeted
layer, exactly as the contract specifies ("one elaboration, zero builds").

**S5 and S7 combinations are permitted only if** each required input form
**actually reaches the intended production driver** and has **its own observed
result inside the receipt**. Merely setting an outer `LEAN_PATH` that Lake
overwrites does **not** exercise that input — the auditor identified this
correctly and it is now binding. Instrumented mandatory-path evidence must be
**labelled as instrumented**, preserving the actual candidate driver except for
the one named input. Direct-driver checks remain **distinct evidence, separately
counted**.

**S8 admits no warm-artifact substitute.** A copied warm artifact is **not**
evidence that the accepted-base Row B declarations were recompiled. Require
actual base source and compiled provenance, and an **observed rebuild of the
affected modules**, before consuming them; reuse only justified, unaffected build
dependencies. Verify the source-blob equivalence between `d670323` and `4a6cd87`
from the repository rather than trusting the parent's read — already done and
recorded at `evidence/base-blob-equality.txt`. **No presence-only substitute for
either obligation.**

## If this does not fit

If a combined call cannot establish each of its rows, or if setup or extra calls
would push the total past ten, **return that new concrete gap before overrun**.
Do not spend past ten and do not silently omit a row.

## Out of scope

No verdict coaching, no candidate edit, no owner build, no restart, no merge, no
acceptance. Upward reports are local files only.
