# POST-START AUTHORIZATION 002 — NOTE-046 WITHDRAWN. Contract returns to 8/30.

Source: desk NOTE-047 (`admitted/NOTE-047-quality-correction-to-desk-046.md`),
which supersedes NOTE-046's S9/S10 requirement **and its associated raise**.

`POST-START-AUTHORIZATION-001-ten-call-table.md` and NOTE-046 are **preserved,
not rewritten**. This document supersedes their ceiling and their S9/S10 rows.

## What changes

- **Substantive ceiling returns to 8. Targeted stays 30.** The 8 → 10 raise is
  withdrawn as unnecessary.
- **S9 and S10 are withdrawn.** Neither was executed — verified from this
  auditor's own journal, which carries no `id=S9` or `id=S10` invocation.
- **The withdrawn calls are NOT credit.** They are not refundable spend, not a
  reserve, and not two freed slots to spend elsewhere. The table is eight named
  uses again.

The desk read `OWNER-BRIEF.md` elements 4 and 5 and
`S2-SUCCESSOR-CAMPAIGN-PROPOSAL.md` directly and found the parent's contract
reading correct: element 5 says **one elaboration, zero builds**, and element 4
requires **distinct clean omission controls**, not whole builds.

## A correction to the parent's own justification — do not carry it forward

A-001 argued that an instrumented whole build "tests the injection harness, not
the mandatory path". **That is an overclaim and it is withdrawn.**
Input-injected whole-path testing is **not categorically** a harness test; it can
genuinely test the driver under declared injected inputs.

The correct and narrower justification, which is the one to use:
**that layer is not required by this contract and is not necessary for the
omission or authority claims here.** One overclaim is not to be replaced with
another.

Mandatory-path necessity is carried by **S3, S4 and S6**, which reach their
guards without instrumentation, together with the clean direct controls.

## What survives from NOTE-046, unchanged and still binding

- **S8's compiled-base provenance condition.** The accepted-base declarations
  must be **compiled from verified base sources**, with justified reuse of
  unaffected dependencies only, and **both** the `Expr` comparison and the
  consumer scan must use **those** artifacts. A copied warm artifact is not
  evidence that the Row B declarations were recompiled. No presence-only
  substitute for either obligation.
- **Interceptor transparency**, exactly as stated in A-001: an interceptor that
  claims to forward genuine whole builds unchanged must be **shown** to forward,
  not asserted to.
- **Report actual setup failures and gaps before any overrun.**

## The eight calls, restored

| # | call | state |
|---|---|---|
| S1 | cold `just lean` | EXECUTED exit 0 |
| S2 | full `just ci` | EXECUTED exit 0 |
| S3 | `just lean` + `sorry` | EXECUTED exit 1 — **setup failure, row still owed** |
| S4 | `just lean` + forbidden axiom + consuming theorem | pending |
| S5 | `just lean` + outside-namespace module + vendor/dependency form | pending |
| S6 | `just lean`, S3 poison retained, axiom gate removed | pending |
| S7 | `just lean` symlink / relative loader form | pending |
| S8 | base rebuild at `d670323` — `Expr` equality + consumer scan | pending, mandatory |

**Spend at this writing, read from the journal: 3/8 substantive, 10/30 targeted.**

Six rows remain (S3 retry, S4, S5, S6, S7, S8) against five remaining slots.
**That is a concrete gap of exactly one substantive invocation — nine required
against a cap of eight.** It is escalated to the desk; hold substantives pending
disposition and continue targeted work within 30.
