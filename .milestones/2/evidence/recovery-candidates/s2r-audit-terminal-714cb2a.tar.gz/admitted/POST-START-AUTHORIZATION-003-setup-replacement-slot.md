# POST-START AUTHORIZATION 003 — substantive 8 → 9, one bounded replacement slot

Source: desk NOTE-048 (`admitted/NOTE-048-quality-q002-one-setup-attempt.md`),
following NOTE-047, **not** the withdrawn NOTE-046 ten-call table.

Authorizations 001 and 002, and NOTE-046, are preserved and not rewritten.

## Two separate decisions — recorded separately, as required

**Decision 1 — scope (NOTE-047).** NOTE-046 withdrawn. S9 and S10 withdrawn and
never silently re-added; neither was executed. They are **not credit**. The
original eight-call scope is correct. The parent's A-001 justification is
narrowed: input-injected whole-path testing is not categorically a harness test —
it simply is not required by this contract nor necessary for these claims.

**Decision 2 — budget (NOTE-048).** **Substantive ceiling 8 → 9 TOTAL**, solely
to replace the one spent setup attempt. Targeted **30** and **one submission**
unchanged. **No reserve.** Not general headroom, and unrelated to Decision 1.

## Arithmetic

**3 spent + 6 required = 9.**

| spent | outcome |
|---|---|
| S1 cold `just lean` | exit 0, row delivered |
| S2 full `just ci` | exit 0, row delivered |
| S3 `just lean` + `sorry` | exit 1, **setup failure — spent, not refunded, row still owed** |

Required six: S3 retry · S4 axiom · S5 extension/vendor · S6 poisoned-disabled ·
S7 equivalent paths · S8 rebuilt base.

Targeted at this writing: **10/30** (P01–P10).

## The S3 failure — diagnosed, not merely observed

`evidence/S3-sorry.log` is four lines: `/dev/null: Permission denied` twice from
`nix/lean-dependency-direction.sh`, then `dependency scanner could not find a
known Reactivegas import`, then the recipe failing. The dependency-direction
script failed its **known-import positive control before any Lean build or gate
ran**. A **wrong-layer setup failure, not a kill** — and a wrong-layer failure
never counts as a kill, while the invocation still counts as spent.

Audit worktree confirmed clean at `714cb2a`; the mutation existed only in a
private mount; the failed launcher is preserved as `mounted-run-v1-failed` with
`mounted-run-v2` separately versioned.

## Conditions on the replacement slot

- Preserve and **hash** the failed launcher; keep the corrected one separately
  versioned.
- Validate actual **mount / device / read-only identity** with a **narrow
  preflight**, not a build.
- **Confirm the retry names the corrected artifact.** Live risk: at the parent's
  read, `instruments/mounted-run` — the path S3 invoked — contained no
  `--dev-bind`, while `mounted-run-v2` did. Timestamped observation; verify
  before invoking.
- The **failed cache path already exists**: preserve it or use a new
  attempt-specific cache. Do not rerun into an existence guard and buy a second
  setup failure with the replacement slot.

## Carried forward unchanged

S8 compiled-base provenance (verified base sources, observed recompilation of
affected modules, both `Expr` comparison and consumer scan on those artifacts, no
presence-only substitute, no warm-artifact substitute) · interceptor transparency
· empty **and** unset as two distinct direct elaborations · **report any further
concrete gap before overrun**.

## Not acceptance

PR #88 CI green at `714cb2a` (run `33970297094` success 2026-09-05T14:16:09Z;
artifacts `33970297155` success; draft true; closing refs `[]`). This does not
accept the candidate and does not replace the audit.
