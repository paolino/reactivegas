# NOTE-004 — proposed claim boundary on root containment. NOT a new control.

**This imposes no new mandatory test, no new build, and no budget.** It is a
proposed invariant / claim boundary for you to assess at **your own severity**
against the frozen contract and the actual Lake configuration. It is not a
predetermined verdict and it is not verdict coaching. If you judge it out of
scope or not a finding, say so and why.

## The boundary

`artifactInsideRoot` canonicalizes the resolved `.olean` with `IO.FS.realPath`
and tests containment under the canonical repo root. It does **not**
independently bind each resolved artifact to **its own package's** source root.

So the measured relation is: **loaded-artifact containment under one canonical
root, plus independent S/B reconciliation.** The Element 2 header phrase "actual
project/dependency source-output relation" is **stronger than that**.

Concretely: a dependency whose real compiled output lives **physically under the
repo root** — a genuinely local Lake dependency materialized in
`.lake/packages`, as opposed to a symlink pointing outside — would satisfy
containment and be classified as project-owned.

**The already-tested aliased vendor entry does not exercise this.** That entry
realpaths *outside* the root into the Nix store, which is the opposite physical
layout. Do not treat them as the same control or let one stand in for the other.

Keep this distinct from the shadowing and `CI-T-SHARED-FILTER` limits already
declared; it is a different assumption.

## What I established at zero cost, for your assessment — verify it yourself

Source and configuration inspection only, no build, no spend:

- `lean/lakefile.lean` declares **no `require`** — no Lake dependencies.
- `lean/lake-manifest.json` has **`"packages": []`** and
  `"packagesDir": ".lake/packages"`.
- `lean/.lake/packages` **does not exist** on disk (`build`, `config`, `vendor`
  only).
- `scripts/check-lean-axioms` has **no `.lake/packages` carve-out**:
  `artifactInsideRoot` is `realPath` then `rootCanon.isPrefixOf`, nothing more.

So on my read the boundary is **real as a claim-scope matter but not a present
defect**: `packagesDir` resolves *inside* the canonical root and there is no
carve-out, yet the package set is empty, so nothing can currently be
misclassified. It is a **latent** assumption that becomes live the moment a
`require` is added and Lake materializes a dependency under the root.

**Separately, and in the candidate's favour — I checked and it holds:**
`canonRoot` appends a trailing `/` before the prefix test, so the sibling
directory hole is genuinely closed (`/code/reactivegas-66-s2r/` does not prefix
`/code/reactivegas-66-s2r-audit/...`). That is not a defect and I am recording it
as verified rather than leaving it as an open suspicion.

## The minimum, whatever severity you assign

Do not let an **unqualified** claim stand that canonical root containment is a
universal package-ownership oracle. A precise **current-source / current-loader**
guarantee with its **physical-layout assumption stated** is reviewable; the same
guarantee with the assumption hidden is not. That applies to the packet's Element
2 wording and to anything you write.

Assess, and report as a proposed invariant or an actual finding at whatever
severity you judge — including "not a finding", with the reason.

No candidate edit, extra submission, new build allowance, or verdict coaching.
The existing full mandate and the closeout continue unchanged.
