# NOTE-002 — contract completion; the brief was incomplete. Bind this before work.

Post-START amendment. Your START at 2026-09-05T14:01:11.657Z stands and is
valid; nothing here is backdated and nothing you have recorded is invalidated.
You are at 0/8 and 0/30 with no build or probe run, so nothing is wasted. Do not
restart. Preserve this seat, its worktree and its evidence.

Four corrections to the brief you bound as `39702bfe…`. Where this note and that
brief conflict, **this note governs**.

## 1. A mandatory row was missing from the substantive table — restored

The frozen auditor allocation (`S2R-CONTROL-RECONCILIATION.md` row 7, and
`S2-BUDGET-PLAN-SUBMISSION3.md` row 6, wording preserved) allocates:

> **rebuilt base** — compiled `Expr` equality for the licensed renames **and**
> the compiled base consumer scan for the removed wrappers — one build serving
> both purposes.

My brief's table carried only "Row B presence/absence" and treated S8 as a
reserve. That was wrong and it narrowed the mandate. **Presence/absence proves
only that the nine identities moved. It does not prove the renamed declarations
are value-preserving, and it does not establish the base's consumer extent for
the three removed wrappers.**

**S8 now carries this mandatory base rebuild. It is not a spare.** Substantive is
therefore 8 named and **zero reserve**: any failed setup or repair is a gap you
report, not a slot you spend.

### Which base to rebuild, and why it is justified rather than assumed

The frozen contract names `4a6cd87`. The candidate's actual parent is the later
accepted `d670323`. I verified the substitution rather than assuming it —
zero-cost `git rev-parse` on the owned blobs:

```
lean/Reactivegas/Invariants.lean   d6d05c2e7436c0c4507f747bdddda1f98f7bbe3a  IDENTICAL at 4a6cd87 and d670323
lean/Reactivegas/TraceTests.lean   509d032def0e45996eb57d41b19fafe190c13d6e  IDENTICAL
lean/Reactivegas/Predicates.lean   2b2cf73f238a7b24c1c10436abb76e22ac3a6255  IDENTICAL
```

All three Row B-owned sources are byte-identical blobs across the two bases, so
the comparison is licensed. **Rebuild `d670323`**, not `4a6cd87`: it carries the
same Row B sources *and* the candidate's actual compiled extent (27 modules
including `CorpusExport`), so the consumer scan covers the extent the candidate
really sits on rather than a 26-module extent that no longer exists. Record this
substitution and its justification in your report; if you judge `4a6cd87`
necessary instead, say why and run that — but do not run both, and do not treat
the choice as free.

### A zero-cost source finding — an input, not a substitute

`git grep` over `d670323` shows the nine Row B names occurring only in
`Invariants.lean` and `TraceTests.lean`, and `CorpusExport.lean` consuming none
of them. That narrows what you should expect. It does **not** discharge the
obligation: the contract asks for the **compiled** consumer scan, which catches
what a source grep cannot — references through `open`, re-export, or elaborated
terms. Run the scan.

## 2. Bind the complete original authority, by path and hash

A frozen copy is at `admitted/` in your runtime, with `MANIFEST.sha256`:

| document | sha256 | standing |
|---|---|---|
| `SUBMISSION-ADMITTED.md` | `32299d25cae31c9dcd8a6d6737e61bb6fe35b48bd4a8e6f041949cff13319bff` | **the admitted owner packet — audit this copy** |
| `S2-FROZEN-PACKET.md` | `99fe06ab253517cbd0002717dc08680b73fd1291dffeb9c76b058f5ab2a38a6e` | AMENDMENT-1 and **A2′'s eight binding constraints** |
| `S2-SUCCESSOR-CAMPAIGN-PROPOSAL.md` | `5ef67ef40695bfe77b648fd4af306842409dee0c7b28b276548075440de0dcb3` | the five named elements; allocations |
| `S2R-CONTROL-RECONCILIATION.md` | `4ba46889158185d09592d25b292b31e232883da4703f973bdff86231de1eae81` | frozen invocation allocation incl. row 7 |
| `S2-BUDGET-PLAN-SUBMISSION3.md` | `591b235a262f7b1bb6f8db44cb8216b699d98519992128d8ae7b1bc5898a7a52` | the `Expr` equality / consumer scan wording |
| `OWNER-BRIEF.md` | `be6e9416a3e96da6d9ebfe564fe7dac56bf52351270f500cd5bba77b1bf1c7b6` | what the owner was actually told |
| `NOTE-041/042/043/044/045` | see manifest | current S2R amendments, binding |

**`handoffs/S2-MANDATE.md` (`649b91da…`) is HISTORY, not authority.** Its §4
offers "named residuals pointing at the script that really enforces each" as an
alternative to honest implementations. That proposal is superseded: the candidate
implements honest **renames**, and the enforcement moved to real mechanisms. Do
not audit against it, and do not let it re-enter as authority.

The packet supersession chain, all citable:
`601e52ab…` (admission) → `041b5a52…` (NOTE-008 §8/§9 corrections) →
`32299d25…` (**admitted; §8 records the executed remote leg**).
Audit the frozen `admitted/SUBMISSION-ADMITTED.md`. My earlier instruction to
"read whatever is on disk and record its hash" is withdrawn — a moving target is
not an audit subject. If the live file diverges from the frozen copy, that
divergence is itself a finding; report it rather than following it.

## 3. Factual correction to the brief's opening

The brief said a fourth candidate, "`fa01779`-era S2", was superseded. **That is
wrong.** `fa01779` was the accepted **S1** repaired candidate, tree-identical to
the landed `4a6cd87`. There is no basis for turning an accepted S1 identity into
a rejected or superseded S2 candidate. The rejected S2 candidates are exactly
three: `5745a2c`, `561347d`, `b0c2cdb`.

## 4. Classify by the actual invocation, and report a gap rather than reclassifying

The frozen allocation budgets several controls as **substantive** that my brief
listed under targeted — the equivalent-path legs, the alias/vendor dependency
control, project-owned `B \ S`, and the missing-authority control. The owner ran
those as direct-`lean` probes; an auditor running them through the mandatory path
runs whole builds.

Per NOTE-033, you are **not** asked to decide whether cached warmth suffices. You
**enumerate the actual invocation class** of each control you intend to run — a
whole build is substantive under any wrapper, `nix develop -c` included, and
failed and warm calls count — and **if the complete set exceeds 8/30, you return
the exact gap before you overrun**. Do not reclassify a frozen substantive row as
targeted to make the arithmetic fit. Under-running the mandate to stay in budget
is the failure; reporting the gap is the correct outcome.

Everything else in the brief stands, including both settling obligations: the two
omission controls re-executed on your own clean artifacts with no unrelated
finding, and the decoy test applied to the new gate.

No candidate edit, no restart, no owner build, no merge, no extra submission,
no outward action. Finish preflight and proceed once genuinely bound.
