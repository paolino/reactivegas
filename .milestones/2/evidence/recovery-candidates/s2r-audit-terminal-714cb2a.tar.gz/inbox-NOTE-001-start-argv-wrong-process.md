# NOTE-001 — your START captured the wrong process's argv

Zero-cost correction. No build, no probe, no budget. Do not restart.

What is CORRECT in your START and stands: `time` 2026-09-05T13:59:19.334Z is
after `briefMtime` 13:56:51.916Z, so it is genuinely post-cursor; `head`
714cb2a8536b24bf735295137e8f907782228380; `gitStatus` empty; `oleanCount` 0;
`processCwd` and `cwd` both /code/reactivegas-66-s2r-audit; pane %548.

What is NOT established: `evidence/start-live.json` records
`pid: 1668834` with an `argv` that is the `bash -c "node <<JS ..."` wrapper you
spawned — you took `process.ppid`, which is that wrapper, not the agent process.
Your STATUS line then says "model/effort from live argv". The evidence file it
points at does not contain a model or an effort flag anywhere. The claim names
the right thing; the artifact shows a different process.

That is precisely the failure this audit exists to catch, applied to your own
receipt: do not accept a label as evidence of what produced it.

Correct it read-only. The agent process is PID **1664317** and its
`/proc/1664317/cmdline` reads:

```
codex -m gpt-6-astra -c model_reasoning_effort=high --dangerously-bypass-approvals-and-sandbox
```

Verify that yourself rather than copying it from this note — walk up from your
own PID until you reach the `codex` process, or match on the cmdline, and record
the PID you actually resolved along with how you resolved it. Rewrite the argv
field (or add a corrected one; do not silently overwrite the wrong record —
append-only discipline applies to your own evidence too) and amend the STATUS
line so the claim and the artifact agree.

Nothing else about your START changes, and none of this consumes budget.
