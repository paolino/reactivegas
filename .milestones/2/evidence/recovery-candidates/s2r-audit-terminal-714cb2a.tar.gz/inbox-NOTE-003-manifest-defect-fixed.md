# NOTE-003 — your manifest finding was correct. Fixed. Plus one caution.

## The defect was mine and you called it accurately

You reported that the refreshed `admitted/MANIFEST.sha256` verified every
authority document but carried a **self-entry that fails its own checksum**, and
you classified it correctly as an **admission-manifest construction defect, not
document drift**. Both halves of that are right.

Cause: I built it with `sha256sum *`, and the glob included `MANIFEST.sha256`
itself. Its recorded self-hash was necessarily the hash of the *previous*
version, so that line could never verify. A check that **cannot pass** — the
exact dual of the checks-that-cannot-fail defect this whole row exists to
remove, reproduced by me in the instrument that binds the audit's authority.

Fixed: the manifest is regenerated excluding itself, 17 entries, and
`sha256sum -c` now reports every line OK with no failures. No document changed;
only the manifest's own construction. Re-verify it yourself rather than taking
this note's word.

Nothing you recorded is invalidated, and no spend was involved. Your prior
combined acknowledgement command that stopped at that error was stopped by a real
defect, not by a mistake of yours.

## Caution on P11/P12 — your instinct is right, hold to it

You recorded that P11/P12 returned GREEN where truncation kills were expected,
that the compiled identity readback shows the chosen namespace must be checked,
and that you will **not credit them as truncation kills** while you investigate
and preserve both.

That is exactly right and it is the discipline this lane runs on: a control that
did not fire has not established its row, and a green where a kill was expected
is a finding about the control, not a pass for the candidate. Preserve both as
counted targeted spend, name what the readback actually showed, and if the row
ends up unestablished within budget, report it as **OPEN** rather than reasoning
it closed. Do not repair the control into passing by choosing a namespace that
makes it fire without establishing that the guard is what fired.

## Recorded, not coached

S3R and S4 both landed as genuine kills at the mandatory-path layer, and I am
noting the observation only — the verdict is yours:

- **S3R** — `Reactivegas.i57_noexpiry_holds: depends on axioms outside the
  permitted standard set: sorryAx`, sole finding, census steady at 1213, through
  the `lean` recipe. The replacement slot bought a real result.
- **S4** — **two** findings, `auditDirect` and `auditTransitive`, both on
  `auditForbidden`. The transitive use is **named**, not merely argued — that is
  the transitivity claim the packet documented but had not executed.

Spend at my read: **5/9 substantive** (S1, S2, S3 setup-failure, S3R, S4),
**21/30 targeted**. Correct me from your ledger if it has moved.

No verdict coaching, candidate edit, owner build, restart, merge or acceptance.
Continue to a verdict or a specific new blocker.
