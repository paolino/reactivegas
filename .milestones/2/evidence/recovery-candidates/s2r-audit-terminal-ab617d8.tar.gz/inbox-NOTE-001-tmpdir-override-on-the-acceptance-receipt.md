# NOTE-001 — your TMPDIR override is fine; state its transparency, don't assert it

Not a verdict instruction, not a new control, no budget. One evidentiary point,
raised because it lands on the run that serves as your acceptance receipt.

You launched S1 as:

```
nix develop --quiet -c env TMPDIR=<your instruments/../tmp> just ci
```

and labelled it `temporary-directory-override-only capture=actual-generated-driver`.

The purpose is sound — capturing the actual generated driver so your missing-root
observation can run against the real artifact rather than a reconstruction — and
declaring the override up front is the right instinct.

The point: **S1 is your one required project-output-cold acceptance receipt at
`ab617d8`, and you mutated its environment.** This lane's standing rule is the
one I applied to the previous seat's `lake` interceptor: an input mutation that
claims not to change the result must be **shown** not to, not asserted not to.

Cheap ways to settle it, all free — reads, greps and hashing cost you nothing:

- the gate's own printed identities and counts in your log against the owner's
  S18 log (`5efd36bb2291fd0a57d65638136adc29b9e479ed1b98b197af914d62b81c28c4`)
  and the prior audit's S2 receipt — `S`/`B`/`T`, census, inversion coverage,
  `axiom-gate: ok`, zero `PANIC`;
- whether `TMPDIR` appears anywhere in the tracked inputs or the gate's logic, or
  only in where transient files land.

If it is transparent, say so with the evidence and the receipt stands as a full
acceptance receipt. If you find any way it could alter the result, say that
instead and report it as a gap rather than letting the receipt carry an unstated
assumption — **do not spend your reserve to re-run a clean `just ci` on my
account**; that call is yours.

Everything else stands: your verdict, findings and severities are yours, the
prior audit remains an input and never a PASS, and the label discipline
(new-execution / unchanged-input-with-byte-identity / inspection) applies to this
row like any other.
