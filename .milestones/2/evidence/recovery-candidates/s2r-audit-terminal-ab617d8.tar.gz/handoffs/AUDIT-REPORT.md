# Independent full-candidate S2R submission 2 audit

**Terminal verdict: AUDIT-PASS.** All 32 integrated rows below are CLOSED within the declared scope. The previous advisory about missing REACTIVEGAS_ROOT is corrected. No blocking functional defect or remaining in-scope documentation finding was established. This report is evidence for the commissioning owner, not acceptance or merge authorization.

Candidate: `ab617d88af9d080de71218f3cc553d60ef0b6de0`. Rejected submission 1: `714cb2a8536b24bf735295137e8f907782228380`. Accepted base: `d67032313acf3699cc50358a057391b88d002192`. Scope is the entire base-to-candidate six-file change, plus the comment correction. Local-only: no candidate edit, author/prior-auditor contact, pane writes, push, PR action, publication, deployment or merge.

## Authority and live identity

Brief SHA256: `f62132c6e829139c8e99fb568a47593af4b5887eb3eda8283c31636b9fdc9977`; NOTE-050 SHA256: `e48f9929b87050ba09cdd1edbe83838340c56acf2f728c3c501c11ee7f71a1f5`. Full original mandate is retained at prior evidence/original-mandate-v2.txt (7cfb7aec95a37448ac7be3c65d900aa47b34fc70127c6d827fa12337e1cf421b), bound with admitted authority and operative A-003. Prior report d634df52c51d4351699d36927b5b0c662357a4ac08a7d689a6708db2d34def90 remains AUDIT-FINDINGS, never an inherited PASS. NOTE-001 is read and acknowledged; its transparency point is resolved below.

Own START 2026-09-05T20:51:32.112Z postdates brief mtime 20:48:34.188Z. Live PID/PGID 2331552, cwd /code/reactivegas-66-s2r-audit2, pane %555 in supplied rg-s2r-audit2 window, full argv `/nix/store/nqhk0522q8ncygwwx054iq76ckcjll82-codex-0.153.2/libexec/codex -m gpt-6-astra -c model_reasoning_effort=high --dangerously-bypass-approvals-and-sandbox`. Distinct from commissioner %503, Muse owner %544 (live Pi PID 1312702, opencode-go/muse-spark-1.3-contributor/xhigh), and prior Codex auditor %548. No seat reuse. The specifically supplied audit window and NOTE-050 full review/supplement authority govern over generic same-window/repair-only defaults. [Live receipt](../evidence/start-live.json).

## Method, spend and stopping point

This is a fresh full-candidate review plus a verification supplement to the retained campaign. **It is not a full fresh mutation replay.** Every row distinguishes **new-execution**, **unchanged-input** (explicit byte identity plus verified raw retained evidence), and **inspection**. Reading/hashing retained output does not turn it into new execution.

Supplement spent **1/2 substantive, 1/4 targeted**; S2 and T2–T4 unused. Retained campaign remains **9/9 substantive, 29/30 targeted**, 38 calls including charged failures and ineffective attempts. Combined executed count is 10 substantive and 30 targeted, not 40 new calls. No refund, relabel or automatic allowance. NOTE-047 withdrew the proposed 8→10 allocation before those calls; NOTE-048/A-003 granted 8→9 only for the failed setup replacement. NOTE-050 expressly supplies this bounded 2/4 supplement and submission 2 while retaining all spend; older owner increases and submissions remain history in hashed authority, not replenished budget. There is no request or authorization here for a further submission or increase.

Stop reason: required finite row set established, with named limits retained; no exploration tail or budget exhaustion. No new mutation run was necessary. Supplement shell/byte/hash comparator work is free under this brief; initial order-sensitive comparator failure is preserved as an instrument refinement and did not consume a build/probe.

## Comment equivalence and corrected claim

Independent `git ls-tree -rz` comparison binds all 266 entries and modes: only scripts/check-lean-axioms changes, with 265 identical entries. The 19 changed lines are standalone comments at the top, before any heredoc or generated input. Entire executable suffix starting TOOL is identical (9975 bytes; hash in the row below). Actual captured driver hash is f04f53e1726d8c784def7c8cd9cb39c7285ef7abe2562dcf83cf4e785309d45f; it exactly matches current shell generation. Retained reconstructed baseline contains one extra blank line before the otherwise identical Lean body; that difference is explicitly recorded, not claimed byte-identical as a whole.

T1 runs this captured driver, with REACTIVEGAS_ROOT absent and cwd=lean: exit 0, 27 modules, 1213 theorem identities, axiom-gate: ok. The inspected canonRoot catch records an error and main throws for nonempty failures; the wrapper unconditionally exports root. Thus the corrected comment truthfully distinguishes observed missing-variable behavior, inspected root-error behavior, and mandatory wrapper behavior. Its claim of executed empty/unset LEAN_PATH controls is supported by distinct retained P07/P08. It does not claim the root-error branch was executed; this audit also does not make that claim.

## Required cold receipt and TMPDIR transparency

S1 invokes the actual full just ci via a declared TMPDIR override solely to capture the transient driver. It starts with no project outputs and exits 0 in 170034 ms. Full log SHA256 2400910d2227528756813c7c5d370721ae2d08c4f09b12155542619b06f176f6. Toolchain 4.25.0 agrees; dependency direction 17; inversion 14/14 and withheld-backdonate 13/14; census 163/163; S/B 27/27; T 1214/1213/1213; agreement 14/14/0; both corpus files and live values verify. No PANIC or error diagnostics. Haskell warnings are present, with build/format/lint exit 0.

The 2495 selected gate lines match prior S2 in original order (SHA256 ed8cf351fb5bd5bf9168b487757b1a571ddd7a68babebd859b8cfdc04826d4ad). Owner S18 hash 5efd36bb2291fd0a57d65638136adc29b9e479ed1b98b197af914d62b81c28c4 verifies; only axiom-module print order differs. Comparing module multisets explicitly and retaining all other line order establishes identical identities, classifications, counts and outcomes. A comparator deletion of CorpusExport rejects. No tracked input reads TMPDIR; inspected mktemp sites use it for temporary drivers/logs/fixtures/export files, with root authority selected separately from script path. Full logs are not claimed byte-identical, nor is arbitrary temporary-filesystem equivalence claimed. [Transparency evidence](../evidence/ci-transparency.json), [consumer search](../evidence/tmpdir-consumers.txt).

## Integrated row decisions

Command IDs below resolve to exact command/exit/log/hash records in the command register. R/ prefixes mean **retained execution**, not runs in this seat. I/ prefixes are inspection/byte-verification commands. Every row is independently assessed; no prior CLOSED label is used as evidence.

### A1 — CLOSED

**Method:** new-execution (baseline); unchanged-input (controls); inspection (derivations). **Commands:** `S1`, `R/P02`, `R/P03`, `R/P04`, `R/P05`, `R/P17`, `R/P26`.

S=git-tracked/walked 27/27, B=27 loaded project modules, T=1214 occurrences/1213 distinct/1213 fold. All identities match retained independent P17, not just counts. Source/import omissions reject exactly TraceTests or KelGroups.Tests; matching single-guard removals pass. Real git/walk fixtures detect both source discrepancies. **Limit:** T traversals share thmInfo and B. B denotes canonical loaded-artifact containment in the current dependency layout.

### A2′ — CLOSED

**Method:** new-execution (positive census); unchanged-input (growth/poison/omission/comparison); inspection (quota and scope). **Commands:** `S1`, `R/S5`, `R/P24`, `R/S3R`, `R/S4`, `R/P29`.

All eight constraints reconciled separately below. Parsed source and compiled declaration ranges agree at 163/163; valid extension passes at 164/164, omission yields 163/162 with named identity; poison rejects for its dependency. Six inversion obligations remain separate. **Limit:** Source/backed zero-census and wrong-name failure branches are inspected, not individually executed.

### A3 — CLOSED

**Method:** new-execution. **Commands:** `S1`.

Own post-brief START and S1-pre.json establish detached clean ab617d8, zero oleans, no lean/.lake and no dist-newstyle. Full local CI exited 0 after 170034 ms. **Limit:** Project-output-cold; Nix/toolchain/dependency caches are allowed and were not claimed cold.

### A4 — CLOSED

**Method:** unchanged-input. **Commands:** `R/P06`, `R/P09`, `R/P10`, `R/P26`.

T-zero has S/B=27/27 and exactly one zero-theorem finding. S-zero and B-zero each isolate the named zero guard and reject; shell zero-tracked/zero-walked fixtures also reject. **Limit:** S/B instruments explicitly disable companion diagnostics; no claim that unmodified empty inputs always produce only one diagnostic.

### A5 — CLOSED

**Method:** unchanged-input. **Commands:** `R/S5`, `R/P02`, `R/P03`, `R/P15`, `R/P16`, `R/P24`, `R/S3R`.

Registered AuditOutside.StdClean is included and validExtension swept by actual just lean. Both module omissions and both one-sided theorem truncations reject; existing non-inversion sorry theorem rejects at unchanged census. **Limit:** S3 setup failure and P11/P12 wrong-name attempts remain spent and are not kills.

### A6 — CLOSED

**Method:** new-execution (clean sweep); unchanged-input (dependency controls); inspection (policy). **Commands:** `S1`, `R/S3R`, `R/S4`.

Allowed set is exactly propext, Classical.choice, Quot.sound, extended from the six inversion obligations. S4 rejects auditDirect and def-mediated auditTransitive for auditForbidden, with exactly two dependency findings; S3R rejects sorryAx. **Limit:** Unused axiom-bearing definitions are outside the thmInfo sweep until used by a theorem.

### A7 — CLOSED

**Method:** new-execution (mandatory path); unchanged-input (necessity); inspection (CI wiring). **Commands:** `S1`, `R/S3R`, `R/S4`, `R/S6`.

Full just ci runs the additive axiom gate through just lean. Same sorry body fails with the gate and passes the complete Lean recipe with only its call removed. Committed CI calls just lean and corpus verification. **Limit:** Local execution and inspected remote command wiring; no remote run or acceptance decision verified.

### A8 — CLOSED

**Method:** new-execution (output); unchanged-input (can-fail wrappers); inspection (total handling). **Commands:** `S1`, `R/P23`.

No PANIC at in S1/T1; exact production suffixes independently byte-bound to ten retained wrapper cases: each green passes, stdout/stderr panic, missing marker and nonzero exit reject. Non-string module components use a sentinel instead of getString!. **Limit:** Commissioned panic-output rule, not mathematical totality; auxiliary exception branches remain unexecuted.

### B1 — CLOSED

**Method:** unchanged-input (compiled names); inspection (honesty). **Commands:** `R/P18`, `R/P29`, `I/diff`.

All nine new compiled names exist, all nine old names and three removed re-exports are absent. Names and comments describe the three actual Bool computations.

### B2 — CLOSED

**Method:** unchanged-input. **Commands:** `R/S8`, `R/P18`, `R/P27`, `R/P29`.

Verified-base rebuild and compiled Expr comparison establish nine exact type/value equalities under only licensed constant-name replacements; all three Bool checks evaluate true. Actual value-mismatch loop rejects the altered comparison. **Limit:** Type-mismatch branch was not separately mutated. Base reuse of unaffected dependencies is justified, not described as total cold recompilation.

### B3 — CLOSED

**Method:** new-execution; unchanged-input (trust necessity); inspection. **Commands:** `S1`, `R/S6`, `I/diff`.

Trust is bound to the mandatory axiom gate, direction to nix/lean-dependency-direction.sh (17 controlled imports), and pinning to scripts/check-lean-toolchain with its mismatch self-test.

### B4 — CLOSED

**Method:** unchanged-input. **Commands:** `R/S8`, `R/P28`, `R/P29`.

All three removed wrappers exist in rebuilt base and not candidate. Scan covers 27 base modules and 3385 constants, types and values including opaque bodies; two positive edges, zero removed-wrapper consumers. Injected reference makes the actual zero-consumer assertion reject. **Limit:** Opaque-body count is zero in this extent. No external/future consumers are covered.

### B5 — CLOSED

**Method:** inspection. **Commands:** `I/diff`.

Comments explicitly avoid impossibility claims about Lean and accurately assign current enforcement to external scripts.

### B6 — CLOSED

**Method:** new-execution; unchanged-input; inspection. **Commands:** `S1`, `R/S3R`, `R/S4`, `R/S6`, `I/diff`.

No named mandatory behavior is left assigned to an unrelated Bool; enforcement is exercised and necessity evidenced. Residual coverage limits are stated below. **Limit:** No guarantee beyond the commissioned row set.

### C — CLOSED

**Method:** inspection. **Commands:** `I/diff`.

Only the Predicates comment changes docs/design/state-machine.md to docs/en/design/state-machine.md; destination exists and no docs file changed.

### §5 — CLOSED

**Method:** inspection; new-execution (actual driver capture). **Commands:** `I/diff`, `S1`.

No permanent Lean driver or Lake registration is introduced. S1 captured the actual temporary AxiomGate.lean; scanner scope remains tracked/walked Lean sources except lakefile and .lake outputs. #70 registrations are unchanged. **Limit:** Conditional permanent-root-driver registration obligation is not triggered.

### AMENDMENT-1 — CLOSED

**Method:** unchanged-input. **Commands:** `R/S3R`, `R/S4`, `R/S5`, `R/S6`.

Sorry poison rejects at steady 163/163 census, while gate-disabled same poison passes; valid growth passes at 164, and the def-mediated forbidden use rejects. Counts cannot substitute for dependency checking.

### F-001 — CLOSED

**Method:** unchanged-input; inspection. **Commands:** `R/S5`, `I/diff`.

Outside-prefix AuditOutside.StdClean is built, imported and swept: S/B=28, T=1214, census=164. Namespace-root whitelist is removed.

### F-002 — CLOSED

**Method:** unchanged-input. **Commands:** `R/P15`, `R/P16`.

Correctly targeted conservation_preserved is absent from exactly one traversal: 1212/1213 and 1213/1212; both reject its identity and the corresponding count disagreement. **Limit:** Wrong qualified-name predecessors P11/P12 are ineffective; shared shrink of both T views remains the bounded advisory.

### F-003 — CLOSED

**Method:** unchanged-input; inspection. **Commands:** `R/S5`, `R/P13`, `R/P17`.

Std-importing project extension stays owned while all 262 Std module artifacts resolve outside root into the pinned Nix store. The implementation does not use the import-Lean closure. **Limit:** Physical in-root dependency packages are a distinct, untested layout; current packages list is empty.

### F-004 — CLOSED

**Method:** unchanged-input; inspection. **Commands:** `R/S5`, `R/S7`, `R/P13`, `R/P14`, `R/P20`, `R/P21`.

Equivalent relative/symlink/alias paths preserve corresponding module/theorem classifications. Actual driver LEAN_PATH is injected after Lake, recorded, and forwarded; the argument-forwarding negative catches a dropped argument. Root and artifact realpaths precede trailing-slash containment. **Limit:** Tests establish the named equivalent-path classes, not arbitrary package layouts or shadow-name safety.

### G-001 — CLOSED

**Method:** unchanged-input. **Commands:** `R/P07`, `R/P08`.

Two distinct direct elaborations with empty and unset LEAN_PATH each reject with exactly ownership authority missing: LEAN_PATH empty or unset. **Limit:** Minimal import-Lean driver reaches the guard without unrelated project-import failure; this is separate from REACTIVEGAS_ROOT.

### Element-1 — CLOSED

**Method:** new-execution (missing root); unchanged-input (resolver controls); inspection (exception text). **Commands:** `T1`, `R/P07`, `R/P08`, `R/P17`, `I/diff`.

Corrected missing-root text is true: actual S1-generated driver with variable unset accepts with 27 modules/1213 theorems via getD ".". Canonicalization failure records a failure propagated to throwError; comment explicitly identifies that branch as inspected, not executed. Wrapper unconditionally exports its resolved root before launching Lean. **Limit:** No independent unresolvable-root control is claimed. Current loader/artifact containment is not universal source-package provenance.

### Element-2 — CLOSED

**Method:** new-execution (current inventory); unchanged-input (resolved extent/extension); inspection (configuration). **Commands:** `S1`, `R/S5`, `R/P17`, `I/diff`.

Tracked source module identities reconcile with actual loaded-artifact identities within the canonical project root. Current lakefile has no require, manifest packages=[], and no materialized .lake/packages. Exporter belongs to the project extent. **Limit:** An actual dependency materialized inside the root would satisfy containment; package-specific origin is not proven. No present such dependency or misclassification is established.

### Element-3 — CLOSED

**Method:** unchanged-input. **Commands:** `R/S5`, `R/S7`, `R/P13`, `R/P14`, `R/P20`, `R/P21`.

Absolute, relative, symlinked invocation and aliased vendor legs classify corresponding identities identically. S5 adds exactly the intentional project extension; S7 and direct path legs retain the baseline. **Limit:** Raw print ordering is not the classification contract.

### Element-4 — CLOSED

**Method:** unchanged-input. **Commands:** `R/P02`, `R/P03`, `R/P04`, `R/P05`.

Prior independent omission controls contain one intended finding each and no unrelated axiom finding; exact matching guard-disabled variants pass. Inputs and clean retained oleans verify. This evidence applies at the unchanged executable candidate. **Limit:** Owner P26/P27 remain contaminated historical evidence and are not credited. These controls were not re-executed here; NOTE-050 expressly licenses this supplement method.

### Element-5 — CLOSED

**Method:** unchanged-input; inspection. **Commands:** `R/P07`, `R/P08`, `I/diff`.

The retained LEAN_PATH guard is live and both required states reject. The retained-branch option is established; no branch retirement is claimed. **Limit:** A-003 withdrew S9/S10 full-build proposals; neither is an obligation or a spent/refunded call.

### Accepted-exporter integration — CLOSED

**Method:** new-execution; unchanged-input; inspection. **Commands:** `S1`, `R/P17`, `R/P29`, `I/diff`.

Cold inventory includes CorpusExport among 27 modules; full CI builds corpusExport and verifies both JSON manifests and live values (5 traces, 32 events, 7 steps). Its registration, corpus inputs and CI wiring are unchanged from the accepted base. **Limit:** Separate exporter mutation campaign is not repeated; remote CI unverified.

### Provenance and fence — CLOSED

**Method:** inspection. **Commands:** `I/identity`, `I/diff`.

Detached final SHA ab617d88af9d080de71218f3cc553d60ef0b6de0 has parent 714cb2a then accepted d670323. Full six-file diff is permitted; nine renames, three deletions, one comment path and two scripts/justfile are accounted for. All model and other tracked inputs are unchanged.

### Comment-only equivalence — CLOSED

**Method:** inspection (independent byte comparison with controls). **Commands:** `I/identity`.

Exactly one mode-preserving file delta, +14/-5 comment lines before TOOL. All 265 other tracked entries identical. Entire 9975-byte executable suffix identical, SHA256 4f1afbe4da7aee6dabac8c4503b697b4a1c2352acc495249aaf9516e5d35b52e. Executable-insertion negative is rejected; comment-insertion positive accepted. **Limit:** The changed prefix contains only standalone shell comments around an identical shebang/set preamble, not a heredoc or quoted context.

### Prior artifact integrity and applicability — CLOSED

**Method:** inspection (hash verification and byte binding). **Commands:** `I/manifests`, `I/retained`.

All seven checked manifests pass: current admission5, prior FINAL14, AUTHORITY31, EVIDENCE103, INSTRUMENTS114, retained earlier INSTRUMENTS90, prior admission17. Copied prior report/final manifest match originals. All 38 receipts match raw logs; clean-olean manifest verifies. Drivers, mutation deltas, wrapper suffixes, input modules and base source bindings independently checked. **Limit:** Hashes establish integrity and input applicability, not a claim those 38 invocations were re-executed.

### NOTE-001 TMPDIR transparency — CLOSED

**Method:** new-execution (S1 output); unchanged-input (comparison logs); inspection (consumers). **Commands:** `S1`, `I/transparency`.

2495 selected gate lines are ordered-byte-identical to prior S2. Owner S18 differs only in module print ordering; explicitly sorted module multisets and all other selected lines agree. No tracked TMPDIR reader; mktemp sites select transient driver/log/fixture/corpus-output locations. Missing-CorpusExport negative rejects. **Limit:** Transparency established for this receipt and the commissioned semantic outputs; no universal equivalence across arbitrary TMPDIR filesystems/permissions or external compiler internals.

## A2′ eight-constraint reconciliation

| Constraint | Decision and evidence method |
|---|---|
|1 Reconciliation retained|CLOSED — new-execution S1 163/163; inspection of parser/compiled-range matching.|
|2 Independent derivations|CLOSED — inspection: source syntax parser versus compiled declaration ranges; unchanged-input R/P24 demonstrates missing counterpart.|
|3 Valid add passes|CLOSED — unchanged-input R/S5, registered outside-prefix theorem,164/164.|
|4 Omission fails|CLOSED — unchanged-input R/P24 names i57_noexpiry_holds source location and 163/162; R/P02/P03 module omissions remain distinct.|
|5 Dependency rejection|CLOSED — unchanged-input R/S3R and R/S4 reject sorryAx/auditForbidden, with steady respective 163/163 and 165/165 census.|
|6 Identities and counts reported|CLOSED — new-execution S1 prints 27 modules/1213 theorem names; inspection confirms quota removal without replacement.|
|7 Six inversion obligations separate|CLOSED — inspection of unchanged requiredInversions/check bodies; new-execution S1 six axiom/bound/tight lines and constructor negative.|
|8 No model or statement weakening|CLOSED — inspection of full diff; unchanged-input R/P29 compiled type/value equality under nine licensed renames.|

## Integrity and retained campaign applicability

[Manifest verification](../evidence/manifest-verification.json), [input equality checks](../evidence/retained-input-check.json), [retained observations](../evidence/retained-execution-observations.json), and [extent matching](../evidence/extent-and-capture.json) contain current verification results. The retained 38 logs and receipts are hash-bound and their observations inspected. All 28 retained clean olean files verify (27 project modules plus Lake configuration). Relevant executable inputs, Lean sources, configurations, toolchain lock and base comparison inputs are unchanged. Canonical worktree relocation is covered by the existing equivalent-path controls and corroborated by current exact baseline identities. Added input, omission, one-guard-disabled, one-sided truncation, sorry and axiom instruments are independently checked against current bytes. Ten wrapper fixture suffixes match current wrappers exactly. Retained base sources match d670323 and its affected-module rebuild is visible; no old owner assertion supplies closure.

## Failure modes and honest limits

Submission2 changes **no executable failure mode**: missing root still defaults, unresolvable root still records an error, missing LEAN_PATH still rejects, and mandatory wrapper still exports root. The full candidate adds explicit source/build/theorem reconciliation, forbidden-dependency rejection and panic/marker propagation; it permits valid census growth. Renames preserve computations and removed wrappers have no consumer in the verified compiled base extent.

The physical ownership assumption remains explicit: containment is not universal package-origin provenance. Current packages=[], with dependencies outside root; an in-root dependency layout requires renewed assessment. CI-T-SHARED-FILTER, shadow-name independence and the previously scoped root-selection comparison remain bounded advisories, not covert new mandatory rows. No all-theorem semantic adequacy, simulator fidelity, exhaustive mutation coverage, universal totality, or external consumer compatibility is claimed.

Auxiliary unexecuted branches remain unexecuted: root/artifact canonicalization exceptions; no-loadable-artifact fallback; source canonicalization/non-string sentinel; source/backed zero and wrong-name census branches; comparator type-mismatch alone; usage/missing-source/build-error wrappers; individual inherited inversion failure branches beyond retained required checks. Missing-root documentation is now CLOSED, while a dedicated root-error execution remains absent. T count-only isolation and post-selection theorem disappearance are construction arguments, not executed necessity claims. R/S3, R/P11 and R/P12 get no semantic kill credit; R/P25 primitive inequality is not credited as the real comparison-loop negative, supplied by R/P27. S3/S4/S5 issue #66 residual work and remote CI/PR acceptance remain with the commissioning owner; this report does not close the issue.

## Command register

The full machine-readable [command ledger](COMMAND-LEDGER.json) preserves exact paths, arguments, exits and raw-log hashes. T1's complete explicit environment is additionally in [its receipt](../evidence/T1-missing-root.receipt.json); no ellipsis in that receipt.

| ID | Command | Exit | Raw evidence |
|---|---|---:|---|
| S1 | `nix develop --quiet -c env TMPDIR=/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-sub2-codex/instruments/../tmp just ci` | 0 | [log/receipt](../evidence/S1-ci.log) sha256=2400910d2227528756813c7c5d370721ae2d08c4f09b12155542619b06f176f6 |
| T1 | `env -u REACTIVEGAS_ROOT LEAN_PATH=<candidate build + pinned toolchain> AXIOM_S_MODULES=<27 tracked modules> /nix/store/4gr3n4nrp0xxgykyyzdxi3xjj2ikn5x1-lean4-4.25.0/bin/lean <captured S1-generated-AxiomGate.lean>; cwd=/code/reactivegas-66-s2r-audit2/lean (exact arguments/environment in T1-missing-root.receipt.json)` | 0 | [log/receipt](../evidence/T1-missing-root.log) sha256=5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161 |
| R/P01 | `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/setup.sh` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P01-environment.log) sha256=7ffc67c66b289e25cfc639dfbbb232981634c42d51b201c753aceeef04105d1f |
| R/P02 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe s-minus-b` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P02-s-minus-b.log) sha256=0aa8b45626e9c5a58a16c11fabcb045baa75f4d531fa61ba3bebd341cbb4904c |
| R/P03 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe b-minus-s` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P03-b-minus-s.log) sha256=cc3d11769342973447ba732e8df81633782a4d3b4d772d3ef19512a30da3c692 |
| R/P04 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe s-minus-b-disabled` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P04-s-minus-b-disabled.log) sha256=77d8f43f7ddbf59e60052121b434c007a144e62b4b8eceea88e595cd8d17939e |
| R/P05 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe b-minus-s-disabled` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P05-b-minus-s-disabled.log) sha256=cacc8364c2c3a02b760ac3e6750a4dd8662465dc27697364cddfa9c10edcfd73 |
| R/P06 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe tzero` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P06-tzero.log) sha256=7abdca4f7673f1178f3725c068376f8abe6a1eb917392cf7f1ba3ff4d0e7eab0 |
| R/P07 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe empty` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P07-empty.log) sha256=5c89a5919f167dc2a317f2b5d951c25dce4634a8a5966df16232cf315a786084 |
| R/P08 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe unset` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P08-unset.log) sha256=5c89a5919f167dc2a317f2b5d951c25dce4634a8a5966df16232cf315a786084 |
| R/P09 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe szero-isolated` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P09-szero.log) sha256=d14acdd1a66a6c6a758939d4777d8455693d074c696a2ca29937036ab1463cd1 |
| R/P10 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe bzero-isolated` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P10-bzero.log) sha256=66e7af644a37ac979c8f3784495da0e8dc5097d4c8844c0cd6a10ebc11f2aa6d |
| R/P11 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe walk-skip` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P11-walk-skip.log) sha256=5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161 |
| R/P12 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe fold-skip` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P12-fold-skip.log) sha256=5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161 |
| R/P13 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe vendor` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P13-vendor.log) sha256=5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161 |
| R/P14 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe relative` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P14-relative.log) sha256=5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161 |
| R/P15 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe walk-skip-v2` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P15-walk-skip-corrected.log) sha256=d41eb769e9fcc94e34827784e28623ce09bd9b812912f3beb8483234afb31ec6 |
| R/P16 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe fold-skip-v2` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P16-fold-skip-corrected.log) sha256=11a8da762101ad002b6e2a73d6b6c2059fb68a5870406afcb83e1c4d277daf7c |
| R/P17 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe extent` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P17-independent-extent.log) sha256=ef046ae5220e95c6703f0da4891775857a5930be30477f91d8f504f7a5af22cb |
| R/P18 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe row-b` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P18-row-b-names.log) sha256=fabbc42a0e412d969f0804c6fbae0a235f06062380dd6d7d98b86531a7375b11 |
| R/P19 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-preflight` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P19-compare-preflight.log) sha256=28769f3e17b8eaba6570ee406518efbdccd623c1a368e84b8e0180fb0ce47cd7 |
| R/P20 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/transparency` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P20-interceptor-transparent.log) sha256=0c85097b589aab27579b0a986db6ffc0de47718250d6b804eca2d71a974dba45 |
| R/P21 | `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/forwarding-test.cjs` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P21-build-forwarding.log) sha256=d1df302314ee41da77e31a54cb30a9468c41b844918ee0b66578e5d99aa1b179 |
| R/P22 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/unset-root` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P22-unset-root.log) sha256=5d299380ef9892fb37df9a436300e8e0a0b180a17bf87e662e50f040c1e54161 |
| R/P23 | `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/wrapper-tests.cjs` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P23-wrapper-controls.log) sha256=68e5602ef4a53e4c875f9b820e3946614f83e8054728487da35c5c855026172d |
| R/P24 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe census-truncation` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P24-source-census-truncation.log) sha256=9cc8a8bbba4eaab6b32247c7c6e3f7c1354fd9a6b72e1ce7ea805dbf0937b633 |
| R/P25 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-base` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P25-compiled-base-comparison.log) sha256=81243c9481bbcc06f1fd9ad59cf7ec56c95bbb44490f3cffe9a33cf5a91cd220 |
| R/P26 | `node /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/source-discovery-tests.cjs` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P26-source-discovery-controls.log) sha256=fca592877def814a75b3ca568e4f37f4cf67951ff6cd16148251bfe36954a6c5 |
| R/P27 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-value-mutant` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P27-comparison-value-negative.log) sha256=ad9598cd6250a2a63f1d4447f6d331e8dfc2d02139b45df3781a089bf7fbb5c8 |
| R/P28 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-consumer-mutant` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P28-consumer-assertion-negative.log) sha256=d6512d0ad849b4bb1539a9a9ca8403e9fca39ab2d75c8c5df109d25ce3542017 |
| R/P29 | `/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/probe compare-base-v2` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/P29-compiled-base-comparison-complete.log) sha256=85c366f184033f0cd840afa5f696d5531fb6d4527dff96f9c9c7b1bfd002d96a |
| R/S1 | `nix develop --quiet -c just lean` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/S1-cold-lean.log) sha256=f5671e859a96f4124608029b21b6ef0f7b8b427b61abe20288bf92b2e05a7989 |
| R/S2 | `nix develop --quiet -c just ci` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/S2-full-ci.log) sha256=e15cef111aa980a2919ee9f233e4ffa87294258b1d1c2d0e22f1cd73e3bd1463 |
| R/S3 | `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run sorry` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/S3-sorry.log) sha256=a4ae770a617f8e8617137f6044a676efff959d4d2407aad74e2a16b5ebe5bca1 |
| R/S3R | `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 sorry` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/S3R-sorry.log) sha256=ec8bfcc1e8107d94b9e5e7b25bcf0d4dbbdcd3d4b8e456a765e8a94a7dd6c1f3 |
| R/S4 | `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 axiom` | 1 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/S4-axiom.log) sha256=dd5e582500b533acd4937e27310453ac4c64213ce5065387ac1da10c9a14be49 |
| R/S5 | `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run vendor` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/S5-extension-vendor.log) sha256=bb117088f4a823dd964950a7290e298b978a507a9ba70a677241053d94c43599 |
| R/S6 | `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v4 disabled` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/S6-poison-gate-disabled.log) sha256=c1647155b29bb3911f261ea64aff41e163aa28971bd152dc10d2ebfaa16749d9 |
| R/S7 | `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/path-run relative` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/S7-symlink-relative.log) sha256=5803fd16bb107ccb0f4a1c2640cbd4e613e096320409544ac55195fa8e1b5066 |
| R/S8 | `nix develop --quiet -c /tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/instruments/mounted-run-v6 base` | 0 | [log/receipt](/tmp/reactivegas/ms2/e-lean-compliance/candidate-auditor-s2r-final-codex/evidence/S8-base-rebuild.log) sha256=3ced274c03b74e67494c0a377e6f92e082ce2948ace4981d674e440cf7cbe5f3 |
| I/identity | `node instruments/identity.cjs; bash -n scripts/check-lean-axioms` | 0 | [log/receipt](../evidence/identity.json) |
| I/diff | `git diff d670323 ab617d8; git rev-parse HEAD HEAD^ HEAD^^; git status --porcelain; git diff --check; cat lean/lakefile.lean lean/lake-manifest.json .github/workflows/ci.yaml; inspect scripts/check-lean-axioms and scripts/check-reactivegas-inversion-coverage` | 0 | [log/receipt](../evidence/full-candidate.diff) |
| I/manifests | `sha256sum -c <each manifest> in its declared root; compare copied prior FINAL/report to originals` | 0 | [log/receipt](../evidence/manifest-verification.json) |
| I/retained | `node instruments/retained-check.cjs; inspect retained instrument/launcher/consumer sources and raw P23/P26/P27/P28/P29/S8 logs` | 0 | [log/receipt](../evidence/retained-input-check.json) |
| I/transparency | `node instruments/compare-ci.cjs; git grep -n -E TMPDIR\|mktemp\|tempDir\|getTemporaryDirectory (pattern passed as one quoted argument)` | 0 | [log/receipt](../evidence/ci-transparency.json) |

## Final boundary

All 32 integrated rows CLOSED using the labeled methods; zero in-scope open findings. This is the auditor's local verdict at the exact candidate, not owner acceptance. Candidate tracked tree remains clean. All evidence, failed comparator version and retained campaign artifacts are preserved. No reserve call spent.
